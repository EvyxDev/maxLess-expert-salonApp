import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:maxless/core/constants/app_colors.dart';
import 'package:maxless/core/constants/widgets/custom_text_form_field.dart';

class ChatInputBar extends StatefulWidget {
  final Function(String) onSendMessage;
  final Function() onUploadImage;
  final Widget? replyBox;

  ChatInputBar({
    required this.onSendMessage,
    required this.onUploadImage,
    this.replyBox,
  });

  @override
  _ChatInputBarState createState() => _ChatInputBarState();
}

class _ChatInputBarState extends State<ChatInputBar> {
  final TextEditingController _controller = TextEditingController();
  bool isTyping = false;

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        if (widget.replyBox != null) widget.replyBox!,
        Row(
          children: [
            // زر رفع الصور
            IconButton(
              icon: Icon(CupertinoIcons.plus, color: Colors.grey),
              onPressed: widget.onUploadImage,
            ),
            SizedBox(width: 8.w),

            // الحقل النصي باستخدام الويدجت المخصصة
            Expanded(
              child: CustomTextFormField(
                controller: _controller,
                borderRadius: 10,
                hintText: "Aa",
                contentPadding:
                    EdgeInsets.only(top: 6.h, left: 10.w, right: 5.w),
                fillColor: Color(0xffF7F7FC),
                onChanged: (value) {
                  setState(() {
                    isTyping = value.isNotEmpty;
                  });
                },
              ),
            ),
            SizedBox(width: 8.w),

            // زر إرسال أو ميكروفون
            IconButton(
              icon: Icon(
                isTyping ? CupertinoIcons.paperplane : CupertinoIcons.mic,
                color: AppColors.primaryColor,
              ),
              onPressed: () {
                if (isTyping) {
                  widget.onSendMessage(_controller.text);
                  _controller.clear();
                  setState(() {
                    isTyping = false;
                  });
                } else {
                  print("Start voice recording...");
                }
              },
            ),
          ],
        ),
      ],
    );
  }
}
