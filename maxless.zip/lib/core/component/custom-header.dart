import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:maxless/core/constants/app_colors.dart';

class CustomHeader extends StatelessWidget {
  final String title;
  final VoidCallback onBackPress;
  final Widget? trailing; // Optional trailing widget

  const CustomHeader({
    Key? key,
    required this.title,
    required this.onBackPress,
    this.trailing, // Add this
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 0.0, vertical: 16.0),
      child: Container(
        margin: EdgeInsets.only(top: 25),
        child: Stack(
          clipBehavior: Clip.none,
          alignment: Alignment.center,
          children: [
            // العنوان في المنتصف
            Center(
              child: Text(
                title,
                style: TextStyle(
                  fontSize: 20,
                  color: Colors.grey[800],
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
            // زر الرجوع
            Positioned(
              left: -10, // جعل الزر في أقصى اليسار
              child: GestureDetector(
                onTap: onBackPress,
                child: Container(
                  width: 60, // زيادة العرض
                  height: 60, // زيادة الارتفاع
                  decoration: BoxDecoration(
                    image: DecorationImage(
                      image: AssetImage(
                        './lib/assets/icons/Union.png',
                      ),
                      fit: BoxFit.fill,
                    ),
                  ),
                  child: Center(
                    child: Icon(
                      CupertinoIcons.arrow_left,
                      size: 20, // تكبير الأيقونة لتتناسب مع الحجم
                      color: AppColors.primaryColor,
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              right: 10, // جعل الزر في أقصى اليسار
              child: Column(
                children: [
                  if (trailing != null)
                    trailing!, // Display trailing if provided
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
