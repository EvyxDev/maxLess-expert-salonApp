import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:maxless/core/component/custom-header.dart';
import 'package:maxless/core/component/custom-notification.dart';
import 'package:maxless/core/constants/navigation.dart';
import 'package:maxless/features/tracking/presentation/pages/map.dart';

class NotificationPage extends StatelessWidget {
  final List<Map<String, String>> notifications = [
    {
      "title": "The beauty expert is 15 minutes away from you",
      "description": "Lorem ipsum dolor sit amet, consectetur adipiscing elit.",
      "image": "./lib/assets/feminism.png",
    },
    {
      "title": "Your order #123456789 has been shipped",
      "description": "Lorem ipsum dolor sit amet, consectetur adipiscing elit.",
      "image": "./lib/assets/testProducts.png",
    },
    {
      "title": "Your order #123456789 has been confirmed",
      "description": "Lorem ipsum dolor sit amet, consectetur adipiscing elit.",
      "image": "./lib/assets/testProducts2.png",
    },
    {
      "title": "Discover hot sale furnitures this week.",
      "description": "Lorem ipsum dolor sit amet, consectetur adipiscing elit.",
      "image": "./lib/assets/testProduct.png",
    },
    {
      "title": "Your order #123456789 has been canceled",
      "description": "Lorem ipsum dolor sit amet, consectetur adipiscing elit.",
      "image": "./lib/assets/test.png",
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          // Custom Header
          SizedBox(height: 20.h),

          CustomHeader(
            title: "Notification",
            onBackPress: () {
              Navigator.pop(context);
            },
          ),
          SizedBox(height: 10.h),

          // Notification List
          Expanded(
            child: ListView.builder(
              physics: BouncingScrollPhysics(), // يجعل التمرير أكثر سلاسة

              padding: EdgeInsets.symmetric(horizontal: 16.w),
              itemCount: notifications.length,
              itemBuilder: (context, index) {
                final notification = notifications[index];
                return Column(
                  children: [
                    GestureDetector(
                      onTap: () {
                        navigateTo(context, TrackingPage());
                      },
                      child: NotificationCard(
                        imageUrl: notification["image"]!,
                        title: notification["title"]!,
                        description: notification["description"]!,
                      ),
                    ),
                    Divider(
                      height: 30.h,
                      thickness: 1,
                      color: Colors.black12,
                    ),
                  ],
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
