import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:image_picker/image_picker.dart';
import 'package:maxless/core/component/custom-header.dart';
import 'package:maxless/core/constants/app_colors.dart';
import 'package:maxless/core/constants/widgets/custom_button.dart';

class ScanQRPage extends StatefulWidget {
  @override
  State<ScanQRPage> createState() => _ScanQRPageState();
}

class _ScanQRPageState extends State<ScanQRPage> {
  bool isSessionStarted = false;
  final ImagePicker _imagePicker = ImagePicker();
  XFile? _capturedImage;

  Future<void> _pickImage() async {
    try {
      final pickedImage =
          await _imagePicker.pickImage(source: ImageSource.camera);
      if (pickedImage != null) {
        setState(() {
          _capturedImage = pickedImage;
        });
      }
    } catch (e) {
      print("Error picking image: $e");
    }
  }

  void _showFeedbackPopup(BuildContext context) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return Dialog(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(15.r),
          ),
          child: SingleChildScrollView(
            child: Padding(
              padding: EdgeInsets.all(16.w),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    "Tell us your feedback 🙌",
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 18.sp,
                      fontWeight: FontWeight.bold,
                      color: Colors.black,
                    ),
                  ),
                  SizedBox(height: 10.h),
                  Text(
                    "Rate the salon based on your experience to improve the service for everyone",
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 14.sp,
                      color: Colors.grey.shade700,
                    ),
                  ),
                  SizedBox(height: 20.h),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: List.generate(5, (index) {
                      return Icon(
                        index < 4
                            ? CupertinoIcons.star_fill
                            : CupertinoIcons.star, // Example rating
                        color: Colors.amber,
                        size: 30.sp,
                      );
                    }),
                  ),
                  SizedBox(height: 20.h),
                  TextField(
                    maxLines: 4,
                    decoration: InputDecoration(
                      hintText: "Write something for us!",
                      hintStyle: TextStyle(fontSize: 14.sp, color: Colors.grey),
                      filled: true,
                      fillColor: Colors.grey.shade200,
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10.r),
                        borderSide: BorderSide.none,
                      ),
                    ),
                  ),
                  SizedBox(height: 20.h),
                  CustomElevatedButton(
                    text: "Send",
                    color: AppColors.primaryColor,
                    textColor: Colors.white,
                    onPressed: () {
                      Navigator.pop(context); // Close the feedback popup
                    },
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: true, // لتجنب المشاكل عند ظهور لوحة المفاتيح
      body: SingleChildScrollView(
        child: Column(
          children: [
            SizedBox(height: 20.h),
            CustomHeader(
              title: "",
              onBackPress: () {
                Navigator.pop(context);
              },
            ),
            Padding(
              padding: EdgeInsets.symmetric(horizontal: 16.w),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Text(
                    "Scan QR",
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 20.sp,
                      fontWeight: FontWeight.bold,
                      color: AppColors.primaryColor,
                    ),
                  ),
                  SizedBox(height: 30.h),
                  Stack(
                    alignment: Alignment.center,
                    children: [
                      Container(
                        height: 280.h,
                        width: 280.w,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          border: Border.all(
                              color: AppColors.primaryColor.withOpacity(0.1),
                              width: 2),
                        ),
                      ),
                      Container(
                        height: 230.h,
                        width: 230.w,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          border: Border.all(
                              color: AppColors.primaryColor.withOpacity(0.1),
                              width: 2),
                        ),
                      ),
                      Container(
                        height: 180.h,
                        width: 180.w,
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(20.r),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.grey.withOpacity(0.3),
                              blurRadius: 8,
                              offset: Offset(0, 4),
                            ),
                          ],
                        ),
                        child: Center(
                          child: Image.asset(
                            "./lib/assets/q.png",
                          ),
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: 30.h),
                  Text(
                    "Please don’t forget to have the salon scan the QR to confirm the start of the session.",
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 14.sp,
                      color: Colors.grey.shade600,
                    ),
                  ),
                  SizedBox(height: 40.h),
                  CustomElevatedButton(
                    text: isSessionStarted ? "End Session" : "Start Session",
                    color: isSessionStarted
                        ? Colors.white
                        : AppColors.primaryColor,
                    textColor: isSessionStarted
                        ? AppColors.primaryColor
                        : Colors.white,
                    borderColor:
                        isSessionStarted ? AppColors.primaryColor : null,
                    onPressed: () async {
                      if (!isSessionStarted) {
                        showModalBottomSheet(
                          context: context,
                          isScrollControlled: true,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.vertical(
                                top: Radius.circular(20.r)),
                          ),
                          builder: (context) {
                            return Padding(
                              padding: EdgeInsets.all(16.w),
                              child: Column(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  ClipRRect(
                                    borderRadius: BorderRadius.circular(15.r),
                                    child: Image.asset(
                                      './lib/assets/testPhoto.png', // المسار الخاص بالصورة
                                      height: 150.h,
                                      width: double.infinity,
                                      fit: BoxFit.cover,
                                    ),
                                  ),
                                  SizedBox(height: 20.h),
                                  Text(
                                    "Take a photo of the product to ensure its safety\nand maintain the health of your hair",
                                    textAlign: TextAlign.center,
                                    style: TextStyle(
                                      fontSize: 14.sp,
                                      color: Colors.grey.shade700,
                                    ),
                                  ),
                                  SizedBox(height: 20.h),
                                  CustomElevatedButton(
                                    text: "Take a photo",
                                    color: AppColors.primaryColor,
                                    textColor: Colors.white,
                                    onPressed: () {
                                      _pickImage();
                                    },
                                  ),
                                ],
                              ),
                            );
                          },
                        );
                      } else {
                        _showFeedbackPopup(context);
                      }
                      setState(() {
                        isSessionStarted = !isSessionStarted; // Toggle state
                      });
                    },
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
