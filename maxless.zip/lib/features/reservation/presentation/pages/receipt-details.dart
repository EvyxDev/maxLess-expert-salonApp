import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:maxless/core/component/custom-header.dart';
import 'package:maxless/core/constants/app_colors.dart';
import 'package:maxless/core/constants/widgets/custom_button.dart';

class ReceiptDetailsPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(height: 20.h),
            CustomHeader(
              title: "Receipt Details",
              onBackPress: () {
                Navigator.pop(context);
              },
            ),
            Padding(
              padding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 20.h),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SizedBox(height: 20.h),
                  Row(
                    children: [
                      // صورة الملف الشخصي
                      ClipRRect(
                        borderRadius: BorderRadius.circular(12.r),
                        child: Image.asset(
                          "./lib/assets/prof.png",
                          height: 60.h,
                          width: 60.w,
                          fit: BoxFit.cover,
                        ),
                      ),
                      SizedBox(width: 12.w),
                      // النصوص
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            "Layla Omar",
                            style: TextStyle(
                              fontSize: 16.sp,
                              fontWeight: FontWeight.bold,
                              color: AppColors.primaryColor,
                            ),
                          ),
                          SizedBox(height: 4.h),
                          Row(
                            children: List.generate(5, (index) {
                              return Icon(
                                Icons.star,
                                size: 16.sp,
                                color: index < 4 ? Colors.amber : Colors.grey,
                              );
                            }),
                          ),
                        ],
                      ),
                    ],
                  ),
                  SizedBox(height: 20.h),
                  _buildSectionTitle("Your Booking"),
                  SizedBox(height: 10.h),
                  _buildBookingDetails(),
                  SizedBox(height: 20.h),
                  _buildDashedDivider(),
                  SizedBox(height: 20.h),
                  _buildSectionTitle("Price Details"),
                  SizedBox(height: 10.h),
                  _buildPriceDetails(),
                  SizedBox(height: 20.h),
                  Center(
                    child: Column(
                      children: [
                        SvgPicture.asset(
                          'lib/assets/icons/barcode.svg',
                          height: 80.h,
                        ),
                        SizedBox(height: 10.h),
                        Text(
                          "06158310-5427-471d-af1f-bd9029b",
                          style: TextStyle(
                            fontSize: 12.sp,
                            color: Colors.grey,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            )
          ],
        ),
      ),
    );
  }

  Widget _buildSectionTitle(String title) {
    return Text(
      title,
      style: TextStyle(
        fontSize: 16.sp,
        fontWeight: FontWeight.bold,
        color: AppColors.primaryColor,
      ),
    );
  }

  Widget _buildBookingDetails() {
    return Container(
      padding: EdgeInsets.all(16.w),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12.r),
        border: Border.all(color: Color(0xffFFE2EC)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildDetailRow(CupertinoIcons.calendar, "Dates", "12 - 14 Nov 2024"),
          SizedBox(height: 10.h),
          _buildDetailRow(CupertinoIcons.time, "Session duration", "4 hours"),
          SizedBox(height: 10.h),
          _buildDetailRow(CupertinoIcons.phone, "Phone", "021434546"),
        ],
      ),
    );
  }

  Widget _buildPriceDetails() {
    return Container(
      padding: EdgeInsets.all(16.w),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12.r),
        border: Border.all(color: Color(0xffFFE2EC)),
      ),
      child: Column(
        children: [
          _buildPriceRow("Price", "8000.00 LE"),
          SizedBox(height: 8.h),
          _buildDashedDivider(),
          SizedBox(height: 10.h),
          _buildPriceRow("Discount", "800.00 LE"),
          SizedBox(height: 8.h),
          _buildDashedDivider(),
          SizedBox(height: 10.h),
          _buildPriceRow("Total price", "7200.00 LE", isBold: true),
        ],
      ),
    );
  }

  Widget _buildDetailRow(IconData icon, String title, String value) {
    return Row(
      children: [
        Icon(icon, size: 20.sp, color: Colors.black),
        SizedBox(width: 10.w),
        Text(
          title,
          style: TextStyle(
            fontSize: 14.sp,
            color: Colors.grey,
          ),
        ),
        Spacer(),
        Text(
          value,
          style: TextStyle(
            fontSize: 14.sp,
            color: Colors.black,
          ),
        ),
      ],
    );
  }

  Widget _buildPriceRow(String title, String value, {bool isBold = false}) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(
          title,
          style: TextStyle(
            fontSize: 14.sp,
            fontWeight: isBold ? FontWeight.bold : FontWeight.w400,
            color: isBold ? Colors.black : Colors.grey,
          ),
        ),
        Text(
          value,
          style: TextStyle(
            fontSize: 14.sp,
            fontWeight: isBold ? FontWeight.bold : FontWeight.w400,
            color: isBold ? AppColors.primaryColor : Colors.black,
          ),
        ),
      ],
    );
  }

  Widget _buildDashedDivider() {
    return Container(
      width: double.infinity,
      height: 1.h,
      child: LayoutBuilder(
        builder: (context, constraints) {
          final dashWidth = 5.w;
          final dashSpace = 3.w;
          final dashCount =
              (constraints.constrainWidth() / (dashWidth + dashSpace)).floor();
          return Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: List.generate(
              dashCount,
              (index) => Container(
                width: dashWidth,
                height: 1.h,
                color: Colors.grey.shade400,
              ),
            ),
          );
        },
      ),
    );
  }
}
