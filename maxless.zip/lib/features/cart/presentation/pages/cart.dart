import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:maxless/core/component/custom-header.dart';
import 'package:maxless/core/component/custom-product-card.dart';
import 'package:maxless/core/constants/app_colors.dart';
import 'package:maxless/core/constants/navigation.dart';
import 'package:maxless/core/constants/widgets/custom_button.dart';
import 'package:maxless/features/checkout/presentation/pages/checkout.dart';

class CartPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          SizedBox(height: 20.h),

          // Custom Header
          CustomHeader(
            title: "Cart",
            onBackPress: () {
              Navigator.pop(context);
            },
          ),
          SizedBox(height: 10.h),

          Expanded(
            child: Padding(
              padding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 8.h),
              child: Column(
                children: [
                  // Reserve Expert Section
                  Container(
                    padding: EdgeInsets.all(25.h),
                    decoration: BoxDecoration(
                      color: Color(0xFFFFE2EC),
                      borderRadius: BorderRadius.circular(12.r),
                    ),
                    child: Column(
                      children: [
                        Text(
                          "Do you need to book with a beauty expert?",
                          style: TextStyle(
                            fontSize: 14.sp,
                            fontWeight: FontWeight.w500,
                            color: AppColors.primaryColor,
                          ),
                          textAlign: TextAlign.center,
                        ),
                        SizedBox(height: 10.h),
                        CustomElevatedButton(
                          text: "Reserve",
                          color: AppColors.primaryColor,
                          onPressed: () {},
                        ),
                      ],
                    ),
                  ),
                  SizedBox(height: 20.h),

                  // Cart Items Section
                  Expanded(
                    child: ListView.separated(
                      physics:
                          BouncingScrollPhysics(), // يجعل التمرير أكثر سلاسة

                      itemCount: 2, // Replace with dynamic item count
                      separatorBuilder: (context, index) => Divider(
                        height: 30.h,
                        thickness: 1,
                        color: Colors.black12,
                      ),
                      itemBuilder: (context, index) {
                        return ProductCard(
                          imageUrl: './lib/assets/testProduct.png',
                          title: 'SPONGE FREE EFFECT',
                          subtitle: 'Shine repair serum 200ML',
                          price: 3000.0,
                          onAddToCart: () {
                            // Add to cart logic
                          },
                          onFavoriteToggle: () {
                            // Toggle favorite logic
                          },
                          isFavorited: false,
                          isInCartView: true, // Custom prop to show cart layout
                        );
                      },
                    ),
                  ),
                  SizedBox(height: 20.h),

                  // Shipping Information Section
                  Padding(
                    padding: EdgeInsets.symmetric(vertical: 8.h),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          "Shipping Information",
                          style: TextStyle(
                            fontSize: 14.sp,
                            fontWeight: FontWeight.w600,
                            color: Colors.black,
                          ),
                        ),
                        SizedBox(height: 10.h),
                        _buildShippingInfoRow("Total (1 items)", "EGP 3000"),
                        SizedBox(height: 5.h),
                        _buildShippingInfoRow("Shipping Fee", "EGP 0.00"),
                        SizedBox(height: 5.h),
                        _buildShippingInfoRow("Discount", "EGP 0.00"),
                        Divider(
                          height: 20.h,
                          thickness: 1.5,
                          color: Color(0xffF2F2F2),
                        ),
                        _buildShippingInfoRow(
                          "Sub Total",
                          "EGP 3000",
                          isBold: true,
                        ),
                      ],
                    ),
                  ),

                  // Checkout Button
                  Padding(
                    padding: EdgeInsets.symmetric(vertical: 10.h),
                    child: CustomElevatedButton(
                      text: "Checkout",
                      color: AppColors.primaryColor,
                      onPressed: () {
                        navigateTo(context, CheckoutPage());
                      },
                      icon: Icon(
                        CupertinoIcons.right_chevron,
                        color: Colors.white,
                        size: 15.sp,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildShippingInfoRow(String title, String value,
      {bool isBold = false}) {
    return Padding(
      padding: EdgeInsets.symmetric(vertical: 4.h),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            title,
            style: TextStyle(
              fontSize: 14.sp,
              fontWeight: FontWeight.w400,
              color: Colors.black,
            ),
          ),
          Text(
            value,
            style: TextStyle(
              fontSize: 14.sp,
              fontWeight: FontWeight.w400,
              color: Colors.black,
            ),
          ),
        ],
      ),
    );
  }
}
