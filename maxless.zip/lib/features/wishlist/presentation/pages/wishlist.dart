import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:maxless/core/constants/app_colors.dart';
import 'package:maxless/core/constants/widgets/custom_button.dart';
import 'package:maxless/core/component/custom-header.dart';
import 'package:maxless/core/component/custom-product-card.dart';

class WishlistPage extends StatelessWidget {
  final List<Map<String, dynamic>> wishlistProducts = [
    {
      "title": "SPONGE FREE EFFECT",
      "subtitle": "Shine repair serum 200ML",
      "price": 3000,
      "image": "./lib/assets/testProduct.png",
    },
    {
      "title": "SPONGE FREE EFFECT",
      "subtitle": "Hair protein 200ML",
      "price": 3000,
      "image": "./lib/assets/testProduct.png",
    },
    {
      "title": "SPONGE FREE EFFECT",
      "subtitle": "Shine repair serum 200ML",
      "price": 3000,
      "image": "./lib/assets/testProduct.png",
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          SizedBox(height: 20.h),

          // Custom Header
          CustomHeader(
            title: "Wishlist",
            onBackPress: () {
              Navigator.pop(context);
            },
          ),
          SizedBox(height: 10.h),
          Expanded(
            child: Padding(
              padding: EdgeInsets.symmetric(horizontal: 16.w),
              child: ListView.builder(
                physics: BouncingScrollPhysics(), // يجعل التمرير أكثر سلاسة

                itemCount: wishlistProducts.length,
                itemBuilder: (context, index) {
                  final product = wishlistProducts[index];
                  return Column(
                    children: [
                      ProductCard(
                        imageUrl: product["image"],
                        title: product["title"],
                        subtitle: product["subtitle"],
                        price: product["price"].toDouble(),
                        onAddToCart: () {
                          print("Added ${product['title']} to cart.");
                        },
                        onFavoriteToggle: () {
                          print("Toggled favorite for ${product['title']}.");
                        },
                        isFavorited: true,
                        isInWishlistView: true, // إضافة هذه الحالة
                      ),
                      Divider(
                        height: 30.h,
                        thickness: 1,
                        color: Colors.black12,
                      ),
                    ],
                  );
                },
              ),
            ),
          ),
        ],
      ),
    );
  }
}
