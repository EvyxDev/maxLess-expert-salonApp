import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:maxless/core/component/custom-header.dart';
import 'package:maxless/core/constants/app_colors.dart';
import 'package:maxless/core/constants/navigation.dart';
import 'package:maxless/core/constants/widgets/chat-input-bar.dart';
import 'package:maxless/core/constants/widgets/custom_button.dart';
import 'package:maxless/features/profile/presentation/pages/expert-profile-reservatoin.dart';

class ChatBuyProduct extends StatefulWidget {
  @override
  _ChatBuyProductState createState() => _ChatBuyProductState();
}

class _ChatBuyProductState extends State<ChatBuyProduct> {
  final ScrollController _scrollController = ScrollController();

  final List<Map<String, dynamic>> messages = [
    {
      "type": "bot",
      "message":
          "Welcome to Maxille! I'm your AI assistant, here to make your experience smoother and more helpful.",
      "time": "16:30"
    },
    {
      "type": "bot",
      "message": "What’s your hair type?",
      "isQuestion": true,
      "time": "16:32"
    },
    {"type": "user", "message": "Wavy", "time": "16:33"},
    {
      "type": "bot",
      "message": "SPONGE FREE EFFECT\nShine repair serum 200ML",
      "isProduct": true,
      "productImage": "./lib/assets/testProduct.png",
      "time": "16:34"
    },
    {"type": "bot", "message": "Experts", "time": "16:35"},
    {"type": "user", "message": "Expert May Ahmed", "time": "16:36"}
  ];
  final List<Map<String, String>> beautyExperts = [
    {
      "name": "May Ahmed",
      "experience": "2 years",
      "rating": "4.5",
      "image": "./lib/assets/profile.png"
    },
    {
      "name": "Maha Hossam",
      "experience": "3 years",
      "rating": "4.7",
      "image": "./lib/assets/expert.png"
    },
  ];

  void _addMessage(String type, String message) {
    final time = TimeOfDay.now().format(context); // تنسيق الوقت

    setState(() {
      messages.add({
        "type": type,
        "message": message,
        "time": time,
      });
    });

    // التمرير للأسفل عند إضافة رسالة جديدة
    Future.delayed(Duration(milliseconds: 100), () {
      if (_scrollController.hasClients) {
        _scrollController.animateTo(
          _scrollController.position.maxScrollExtent,
          duration: Duration(milliseconds: 300),
          curve: Curves.easeOut,
        );
      }
    });
  }

  Widget _buildSalonChoiceMessage(String salonName) {
    return Container(
      margin: EdgeInsets.symmetric(vertical: 10.h),
      padding: EdgeInsets.all(12.w),
      decoration: BoxDecoration(
        color: Colors.grey.shade100,
        borderRadius: BorderRadius.circular(10.r),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                width: 4.w,
                height: 40.h,
                decoration: BoxDecoration(
                  color: AppColors.primaryColor,
                  borderRadius: BorderRadius.circular(2.r),
                ),
              ),
              SizedBox(width: 8.w),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    "You chose",
                    style: TextStyle(
                      color: AppColors.primaryColor,
                      fontSize: 12.sp,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  SizedBox(height: 5.h),
                  Text(
                    salonName,
                    style: TextStyle(
                      color: Colors.black,
                      fontSize: 14.sp,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ],
              ),
            ],
          ),
          SizedBox(height: 10.h),
          Text(
            "You will get a 10% discount if you book through us. If you want to complete the reservation, click \"End Chat\"",
            style: TextStyle(
              color: Colors.black,
              fontSize: 12.sp,
            ),
          ),
          SizedBox(height: 10.h),
          Align(
            alignment: Alignment.centerLeft,
            child: Text(
              TimeOfDay.now().format(context),
              style: TextStyle(
                color: Colors.grey,
                fontSize: 10.sp,
              ),
            ),
          ),
        ],
      ),
    );
  }

  void _showEndChatDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        alignment: Alignment.center,
        title: Text(
          "Do you want to end chat?",
          textAlign: TextAlign.center,
          style: TextStyle(
              fontSize: 15.sp,
              fontWeight: FontWeight.w400,
              color: Colors.black),
        ),
        content: Text(
          "You will not be able to reply to this chat again.",
          textAlign: TextAlign.center,
          style: TextStyle(
            fontSize: 12.sp,
            fontWeight: FontWeight.w400,
            color: AppColors.primaryColor,
          ),
        ),
        shape:
            ContinuousRectangleBorder(borderRadius: BorderRadius.circular(20)),
        actions: [
          Row(
            children: [
              Expanded(
                child: CustomElevatedButton(
                  text: "Yes",
                  color: Colors.white,
                  borderRadius: 10,
                  borderColor: AppColors.primaryColor,
                  textColor: AppColors.primaryColor,
                  onPressed: () {
                    Navigator.pop(context); // Close the dialog

                    _showReservationFlow(); // Start the reservation flow
                  },
                ),
              ),
              SizedBox(width: 10.h), // مسافة بين الأزرار

              Expanded(
                child: CustomElevatedButton(
                  text: "No",
                  borderRadius: 10,
                  color: AppColors.primaryColor,
                  textColor: Colors.white,
                  onPressed: () {
                    Navigator.pop(context);
                    // Navigator.pop(context); // إغلاق المودال
                  },
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  void _showReservationFlow() async {
    bool wantReservation = await _showReservationDialog();
    if (wantReservation) {
      DateTime? selectedDate = await _showDatePicker();
      if (selectedDate != null) {
        TimeOfDay? selectedTime = await _showTimePicker();
        if (selectedTime != null) {
          _showReservationSuccessDialog();
        }
      }
    }
  }

  Future<bool> _showReservationDialog() async {
    return await showDialog<bool>(
          context: context,
          builder: (context) => AlertDialog(
            title: Text(
              "Want Reservation?",
              textAlign: TextAlign.center,
              style: TextStyle(
                  fontSize: 15.sp,
                  fontWeight: FontWeight.w400,
                  color: Colors.black),
            ),
            content: Text(
              "Do you want to make a reservation?",
              style: TextStyle(
                fontSize: 12.sp,
                fontWeight: FontWeight.w400,
                color: AppColors.primaryColor,
              ),
            ),
            actions: [
              Row(
                children: [
                  Expanded(
                    child: CustomElevatedButton(
                      text: "Yes",
                      color: Colors.white,
                      borderRadius: 10,
                      borderColor: AppColors.primaryColor,
                      textColor: AppColors.primaryColor,
                      onPressed: () {
                        Navigator.pop(context, true);
                      },
                    ),
                  ),
                  SizedBox(width: 10.h), // مسافة بين الأزرار

                  Expanded(
                    child: CustomElevatedButton(
                      text: "No",
                      borderRadius: 10,
                      color: AppColors.primaryColor,
                      textColor: Colors.white,
                      onPressed: () {
                        Navigator.pop(context);
                        // Navigator.pop(context); // إغلاق المودال
                      },
                    ),
                  ),
                ],
              ),
            ],
          ),
        ) ??
        false; // Default to false if dialog is dismissed
  }

  Future<DateTime?> _showDatePicker() async {
    DateTime selectedDate = DateTime.now();
    return await showModalBottomSheet<DateTime>(
      context: context,
      isScrollControlled: true,
      enableDrag: true,
      showDragHandle: true,
      sheetAnimationStyle: AnimationStyle(
        duration: Duration(milliseconds: 200),
      ),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20.r)),
      ),
      builder: (context) {
        return Padding(
          padding: EdgeInsets.all(16.w),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                "Select Date",
                style: TextStyle(
                  fontSize: 16.sp,
                  fontWeight: FontWeight.bold,
                  color: AppColors.primaryColor,
                ),
              ),
              SizedBox(height: 16.h),
              SizedBox(
                height: 300.h,
                child: Theme(
                  data: Theme.of(context).copyWith(
                    colorScheme: ColorScheme.light(
                      primary: AppColors
                          .primaryColor, // لون العناصر الرئيسية (مثل الزر الحالي)
                      onPrimary: Colors.white, // لون النص داخل العناصر الرئيسية
                      onSurface: Colors.black, // لون النص على السطح
                    ),
                  ),
                  child: CalendarDatePicker(
                    initialDate: DateTime.now(),
                    firstDate: DateTime.now(),
                    lastDate: DateTime.now().add(Duration(days: 365)),
                    onDateChanged: (date) {
                      selectedDate = date;
                    },
                  ),
                ),
              ),
              SizedBox(height: 16.h),
              CustomElevatedButton(
                text: "Done",
                borderRadius: 10,
                color: AppColors.primaryColor,
                textColor: Colors.white,
                onPressed: () {
                  Navigator.pop(context, selectedDate);
                },
              ),
            ],
          ),
        );
      },
    );
  }

  Future<TimeOfDay?> _showTimePicker() async {
    TimeOfDay selectedTime = TimeOfDay.now();
    return await showModalBottomSheet<TimeOfDay>(
      context: context,
      isScrollControlled: true,
      enableDrag: true,
      showDragHandle: true,
      sheetAnimationStyle: AnimationStyle(
        duration: Duration(milliseconds: 200),
      ),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20.r)),
      ),
      builder: (context) {
        int hour = selectedTime.hourOfPeriod; // Convert to 12-hour format
        int minute = selectedTime.minute;
        String period = selectedTime.period == DayPeriod.am ? "AM" : "PM";

        void updatePeriod() {
          period = (period == "AM") ? "PM" : "AM";
        }

        return StatefulBuilder(
          builder: (context, setState) {
            return Padding(
              padding: EdgeInsets.all(16.w),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  // Title
                  Text(
                    "Select Time",
                    style: TextStyle(
                      fontSize: 16.sp,
                      fontWeight: FontWeight.bold,
                      color: AppColors.primaryColor,
                    ),
                  ),
                  SizedBox(height: 20.h),

                  // Time Picker UI
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      // Hour Picker
                      Column(
                        children: [
                          IconButton(
                            icon: Icon(
                              CupertinoIcons.chevron_up,
                              color: AppColors.primaryColor,
                            ),
                            onPressed: () {
                              setState(() {
                                hour = (hour % 12) + 1; // Cycle between 1-12
                              });
                            },
                          ),
                          Text(
                            hour.toString().padLeft(2, '0'),
                            style: TextStyle(
                              fontSize: 20.sp,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          IconButton(
                            icon: Icon(
                              CupertinoIcons.chevron_down,
                              color: AppColors.primaryColor,
                            ),
                            onPressed: () {
                              setState(() {
                                hour = (hour - 1) == 0
                                    ? 12
                                    : (hour - 1); // 12-hour cycle
                              });
                            },
                          ),
                        ],
                      ),
                      // Separator
                      Padding(
                        padding: EdgeInsets.symmetric(horizontal: 8.w),
                        child: Text(
                          ":",
                          style: TextStyle(
                            fontSize: 20.sp,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                      // Minute Picker
                      Column(
                        children: [
                          IconButton(
                            icon: Icon(
                              CupertinoIcons.chevron_up,
                              color: AppColors.primaryColor,
                            ),
                            onPressed: () {
                              setState(() {
                                minute =
                                    (minute + 1) % 60; // Cycle between 0-59
                              });
                            },
                          ),
                          Text(
                            minute.toString().padLeft(2, '0'),
                            style: TextStyle(
                              fontSize: 20.sp,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          IconButton(
                            icon: Icon(
                              CupertinoIcons.chevron_down,
                              color: AppColors.primaryColor,
                            ),
                            onPressed: () {
                              setState(() {
                                minute = (minute - 1) < 0
                                    ? 59
                                    : (minute - 1); // Cycle backward
                              });
                            },
                          ),
                        ],
                      ),
                      // Period Picker (AM/PM)
                      Padding(
                        padding: EdgeInsets.symmetric(horizontal: 16.w),
                        child: Column(
                          children: [
                            IconButton(
                              icon: Icon(
                                CupertinoIcons.chevron_up,
                                color: AppColors.primaryColor,
                              ),
                              onPressed: () {
                                setState(() {
                                  updatePeriod();
                                });
                              },
                            ),
                            Text(
                              period,
                              style: TextStyle(
                                fontSize: 16.sp,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            IconButton(
                              icon: Icon(
                                CupertinoIcons.chevron_down,
                                color: AppColors.primaryColor,
                              ),
                              onPressed: () {
                                setState(() {
                                  updatePeriod();
                                });
                              },
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: 20.h),

                  // Done Button
                  CustomElevatedButton(
                    text: "Done",
                    borderRadius: 10,
                    color: AppColors.primaryColor,
                    textColor: Colors.white,
                    onPressed: () {
                      final time = TimeOfDay(
                        hour: (period == "PM" && hour != 12)
                            ? hour + 12
                            : (period == "AM" && hour == 12 ? 0 : hour),
                        minute: minute,
                      );
                      Navigator.pop(context, time);
                    },
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }

  void _showReservationSuccessDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: SvgPicture.asset("./lib/assets/icons/check.svg"),
        content: Text(
          "Your reservation has been completed successfully!",
          textAlign: TextAlign.center,
          style: TextStyle(fontSize: 16.sp, fontWeight: FontWeight.bold),
        ),
        actions: [
          Center(
            child: CustomElevatedButton(
              text: "OK",
              borderRadius: 10,
              color: AppColors.primaryColor,
              textColor: Colors.white,
              onPressed: () {
                print("No");
                Navigator.pop(context);
              },
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          // Header Section
          SizedBox(height: 20.h),

          CustomHeader(
            title: "Reservation",
            onBackPress: () {
              Navigator.pop(context);
            },
            trailing: TextButton(
              onPressed: _showEndChatDialog,
              child: Text(
                "End Chat",
                style:
                    TextStyle(color: AppColors.primaryColor, fontSize: 14.sp),
              ),
            ),
          ),

          // Messages Section
          Expanded(
            child: ListView.builder(
              controller: _scrollController,
              itemCount: messages.length,
              physics: BouncingScrollPhysics(),
              padding: EdgeInsets.all(16.w),
              itemBuilder: (context, index) {
                final message = messages[index];
                final String messageText =
                    message["message"] ?? ""; // قيمة افتراضية
                final String? messageType = message["type"]; // نوع الرسالة
                final String messageTime = message["time"] ??
                    "${DateTime.timestamp().hour}:${DateTime.timestamp().minute}"; // وقت افتراضي

                if (message["isProduct"] == true) {
                  return _buildProductMessage(
                    messageText,
                    message["productImage"] ?? "", // توفير قيمة افتراضية للصورة
                    messageTime,
                  );
                } else if (message["isQuestion"] == true) {
                  return _buildQuestionCard(messageText);
                } else if (message["type"] == "widget") {
                  return message["widget"] as Widget; // عرض الودجت المخصص
                }

                return _buildMessageBubble(
                    messageText, messageType == "user", messageTime);
              },
            ),
          ),

          // Input Section
          Padding(
            padding: EdgeInsets.all(8.0),
            child: ChatInputBar(
              onSendMessage: (message) {
                if (message.toLowerCase() == "end chat") {
                  _showReservationFlow(); // ابدأ رحلة الحجز
                } else {
                  _addMessage("user", message); // أضف الرسالة العادية
                }
              },
              onUploadImage: () {
                print("Upload image clicked");
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildMessageBubble(String message, bool isUser, String time) {
    return Align(
      alignment: isUser ? Alignment.centerRight : Alignment.centerLeft,
      child: Column(
        crossAxisAlignment:
            isUser ? CrossAxisAlignment.end : CrossAxisAlignment.start,
        children: [
          Container(
            margin: EdgeInsets.symmetric(vertical: 5.h),
            padding: EdgeInsets.symmetric(vertical: 10.h, horizontal: 15.w),
            decoration: BoxDecoration(
              color: isUser ? AppColors.primaryColor : Colors.grey.shade200,
              borderRadius: BorderRadius.only(
                topLeft:
                    Radius.circular(isUser ? 16.0 : 0.0), // إذا كان المستخدم
                topRight:
                    Radius.circular(isUser ? 0.0 : 16.0), // إذا كان من البوت
                bottomLeft: Radius.circular(16.0),
                bottomRight: Radius.circular(16.0),
              ),
            ),
            child: Text(
              message,
              style: TextStyle(
                color: isUser ? Colors.white : Colors.black,
                fontSize: 14.sp,
              ),
            ),
          ),
          Padding(
            padding: EdgeInsets.only(left: 10.w, right: 10.w),
            child: Text(
              time,
              style: TextStyle(
                color: Colors.grey,
                fontSize: 12.sp,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildProductMessage(String message, String imageUrl, String time) {
    return Align(
      alignment: Alignment.centerLeft,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 250.w,
            margin: EdgeInsets.symmetric(vertical: 6.h),
            padding: EdgeInsets.all(10.w),
            decoration: BoxDecoration(
              border: Border.all(color: AppColors.primaryColor, width: 1),
              borderRadius: BorderRadius.circular(12.r),
              color: Colors.grey.shade100,
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Image.asset(
                  imageUrl.isNotEmpty
                      ? imageUrl
                      : "./lib/assets/default.png", // صورة افتراضية
                  height: 110.h,
                  fit: BoxFit.contain,
                ),
                SizedBox(height: 15.h),
                Text(
                  message.isNotEmpty
                      ? message
                      : "No message available", // نص افتراضي
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 12.sp,
                  ),
                ),
                SizedBox(height: 15.h),
                Row(
                  children: [
                    Expanded(
                      child: CustomElevatedButton(
                        text: "Add To Cart",
                        borderRadius: 10,
                        color: AppColors.primaryColor,
                        textColor: Colors.white,
                        onPressed: () {
                          print("No");
                          // Navigator.pop(context); // إغلاق المودال
                        },
                      ),
                    ),
                    SizedBox(width: 10.h), // مسافة بين الأزرار

                    SizedBox(
                      width: 50.w,
                      child: GestureDetector(
                        onTap: () {},
                        child: Icon(
                          CupertinoIcons.heart,
                          color: AppColors.primaryColor,
                          size: 20.sp, // Responsive size
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          Padding(
            padding: EdgeInsets.only(left: 10.w),
            child: Text(
              time,
              style: TextStyle(
                color: Colors.grey,
                fontSize: 12.sp,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildQuestionCard(String question) {
    return Container(
      margin: EdgeInsets.symmetric(vertical: 8.h),
      padding: EdgeInsets.all(12.w),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(15.r),
        color: Colors.white,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header with Icon and Text
          Row(
            children: [
              Icon(
                CupertinoIcons.star_circle,
                color: AppColors.primaryColor,
                size: 16.sp,
              ),
              SizedBox(width: 4.w),
              Text(
                "Collect 2 points for each question you answer",
                style: TextStyle(
                  color: AppColors.primaryColor,
                  fontSize: 12.sp,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ],
          ),
          SizedBox(height: 8.h),

          // Question Text
          Text(
            question,
            style: TextStyle(
              fontSize: 14.sp,
              fontWeight: FontWeight.bold,
              color: Colors.black,
            ),
          ),
          SizedBox(height: 10.h),

          // Options
          Column(
            children: ["Wavy", "Straight", "Curly"].map((option) {
              return Padding(
                padding: EdgeInsets.symmetric(vertical: 6.h),
                child: GestureDetector(
                  onTap: () {
                    _addMessage("user", option); // Add the selected message
                  },
                  child: Container(
                    width: 100.w,
                    decoration: BoxDecoration(
                      color: AppColors.primaryColor,
                      borderRadius: BorderRadius.circular(20.r),
                    ),
                    padding:
                        EdgeInsets.symmetric(vertical: 5.h, horizontal: 10.w),
                    child: Row(
                      children: [
                        Icon(
                          CupertinoIcons.circle,
                          color: AppColors.white,
                          size: 16.sp,
                        ),
                        SizedBox(width: 10.w),
                        Text(
                          option,
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 14.sp,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              );
            }).toList(),
          ),
          SizedBox(height: 10.h),

          // Time
          Align(
            alignment: Alignment.centerLeft,
            child: Text(
              "16:46",
              style: TextStyle(
                color: Colors.grey.shade500,
                fontSize: 12.sp,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
