import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:maxless/core/constants/app_colors.dart';
import 'package:maxless/core/constants/widgets/custom_button.dart';
import 'package:maxless/core/constants/widgets/custom_text_form_field.dart';
import 'package:maxless/core/component/custom-header.dart';

class CheckoutPage extends StatefulWidget {
  @override
  _CheckoutPageState createState() => _CheckoutPageState();
}

class _CheckoutPageState extends State<CheckoutPage> {
  String selectedPaymentMethod = "Credit Card";

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          SizedBox(height: 20.h),

          // إضافة الهيدر
          CustomHeader(
            title: "Checkout",
            onBackPress: () {
              Navigator.pop(context);
            },
          ),
          SizedBox(height: 10.h),

          Expanded(
            child: Padding(
              padding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 8.h),
              child: SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Form Fields
                    Row(
                      children: [
                        Expanded(
                          child: CustomTextFormField(
                            labelText: "Name",
                            hintText: "Name",
                            borderColor: Color(0xffDDE5E9),
                            hintStyle: TextStyle(color: Color(0xffDDE5E9)),
                            borderRadius: 10,
                          ),
                        ),
                        SizedBox(width: 20.w),
                        Expanded(
                          child: CustomTextFormField(
                            labelText: "Phone Number",
                            hintText: "Phone Number",
                            keyboardType: TextInputType.phone,
                            borderColor: Color(0xffDDE5E9),
                            hintStyle: TextStyle(color: Color(0xffDDE5E9)),
                            borderRadius: 10,
                          ),
                        ),
                      ],
                    ),
                    SizedBox(height: 20.h),
                    Row(
                      children: [
                        Expanded(
                          child: CustomTextFormField(
                            labelText: "Appartment",
                            hintText: "Enter your username",
                            borderColor: Color(0xffDDE5E9),
                            hintStyle: TextStyle(color: Color(0xffDDE5E9)),
                            borderRadius: 10,
                          ),
                        ),
                        SizedBox(width: 20.w),
                        Expanded(
                          child: CustomTextFormField(
                            labelText: "Street",
                            hintText: "Enter your username",
                            borderColor: Color(0xffDDE5E9),
                            hintStyle: TextStyle(color: Color(0xffDDE5E9)),
                            borderRadius: 10,
                          ),
                        ),
                      ],
                    ),
                    SizedBox(height: 20.h),
                    CustomTextFormField(
                      labelText: "Address in Detail",
                      hintText: "Enter Your Address",
                      borderColor: Color(0xffDDE5E9),
                      hintStyle: TextStyle(color: Color(0xffDDE5E9)),
                      borderRadius: 10,
                    ),
                    SizedBox(height: 20.h),

                    // Payment Method
                    Text(
                      "Choose Payment Method",
                      style: TextStyle(
                        fontSize: 16.sp,
                        fontWeight: FontWeight.bold,
                        color: Colors.black,
                      ),
                    ),
                    SizedBox(height: 10.h),
                    _buildPaymentMethodOption(
                      isIconSvg: true,
                      icon: "./lib/assets/icons/master.svg",
                      title: "Credit Card",
                    ),
                    SizedBox(height: 10.h),
                    _buildPaymentMethodOption(
                      isIconSvg: false,
                      icon: "./lib/assets/icons/cache.png",
                      title: "Cash On Delivery",
                    ),
                    SizedBox(height: 10.h),
                    _buildPaymentMethodOption(
                      isIconSvg: true,
                      icon: "./lib/assets/icons/wallet.svg",
                      title: "Wallet",
                    ),
                    SizedBox(height: 20.h),

                    // Shipping Information
                    Text(
                      "Shipping Information",
                      style: TextStyle(
                        fontSize: 16.sp,
                        fontWeight: FontWeight.bold,
                        color: Colors.black,
                      ),
                    ),
                    SizedBox(height: 10.h),
                    Divider(
                      height: 20.h,
                      thickness: 1.5,
                      color: Color(0xffF2F2F2),
                    ),
                    SizedBox(height: 10.h),

                    _buildShippingInfoRow("Sub Total", "800 LE", isBold: true),
                    SizedBox(height: 30.h),

                    // Pay Button
                    CustomElevatedButton(
                      text: "Pay",
                      color: AppColors.primaryColor,
                      onPressed: () {
                        print("Payment Process Started");
                      },
                      icon: Icon(
                        CupertinoIcons.right_chevron,
                        color: Colors.white,
                        size: 15.sp,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPaymentMethodOption({
    required String icon,
    required bool isIconSvg,
    required String title,
  }) {
    return GestureDetector(
      onTap: () {
        setState(() {
          selectedPaymentMethod = title;
        });
      },
      child: AnimatedContainer(
        duration: Duration(milliseconds: 200),
        padding: EdgeInsets.all(12.w),
        decoration: BoxDecoration(
          color:
              selectedPaymentMethod == title ? Colors.white : Color(0xFFF9F9F9),
          borderRadius: BorderRadius.circular(12.r),
          border: Border.all(
            color: selectedPaymentMethod == title
                ? AppColors.primaryColor
                : Colors.transparent,
            width: 1.5.w,
          ),
        ),
        child: Row(
          children: [
            isIconSvg
                ? SvgPicture.asset(
                    icon,
                    height: 24.h,
                    width: 24.w,
                  )
                : Image.asset(
                    icon,
                    height: 24.h,
                    width: 24.w,
                    fit: BoxFit.contain,
                  ),
            SizedBox(width: 12.w),
            Text(
              title,
              style: TextStyle(
                fontSize: 14.sp,
                color: Colors.black,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildShippingInfoRow(String title, String value,
      {bool isBold = false}) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(
          title,
          style: TextStyle(
            fontSize: 14.sp,
            fontWeight: FontWeight.w400,
            color: Colors.black,
          ),
        ),
        Text(
          value,
          style: TextStyle(
            fontSize: 14.sp,
            fontWeight: isBold ? FontWeight.bold : FontWeight.w400,
            color: Colors.black,
          ),
        ),
      ],
    );
  }
}
