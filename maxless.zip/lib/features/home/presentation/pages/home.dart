import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:maxless/core/component/custom-product-card.dart';
import 'package:maxless/core/constants/app_colors.dart';
import 'package:maxless/core/constants/navigation.dart';
import 'package:maxless/features/cart/presentation/pages/cart.dart';
import 'package:maxless/features/chatting/presentation/pages/buy-product/buy-product.dart';
import 'package:maxless/features/chatting/presentation/pages/expert/expert-chat.dart';
import 'package:maxless/features/chatting/presentation/pages/salon/salon-chat.dart';
import 'package:maxless/features/notification/presentation/pages/notification.dart';
import 'package:maxless/features/profile/presentation/pages/community.dart';
import 'package:maxless/features/profile/presentation/pages/main-profile.dart';
import 'package:maxless/features/wishlist/presentation/pages/wishlist.dart';

class HomePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        forceMaterialTransparency: true,
        leadingWidth: 150.w,
        leading: Padding(
          padding: EdgeInsets.only(left: 10.w),
          child: Row(
            mainAxisSize: MainAxisSize.min, // لتقليل المساحة المستخدمة
            children: [
              Stack(
                alignment: Alignment.center,
                children: [
                  // الخلفية الدائرية
                  Container(
                    width: 40.w,
                    height: 40.h,
                    decoration: BoxDecoration(
                      color: AppColors.primaryColor.withOpacity(0.1),
                      shape: BoxShape.circle,
                    ),
                  ),
                  // أيقونة المستخدمين
                  IconButton(
                    icon: Icon(
                      Icons.notifications,
                      color: AppColors.primaryColor,
                      size: 24.sp,
                    ),
                    onPressed: () {
                      print('Notifications Clicked');
                      navigateTo(context, NotificationPage());
                    },
                  ),
                ],
              ),
              SizedBox(width: 10.w), // مسافة بين الأزرار

              // زر الإشعارات

              // زر المستخدمين
              Stack(
                alignment: Alignment.center,
                children: [
                  // الخلفية الدائرية
                  Container(
                    width: 40.w,
                    height: 40.h,
                    decoration: BoxDecoration(
                      color: AppColors.primaryColor.withOpacity(0.1),
                      shape: BoxShape.circle,
                    ),
                  ),
                  // أيقونة المستخدمين
                  IconButton(
                    icon: Icon(
                      CupertinoIcons.group_solid,
                      color: AppColors.primaryColor,
                      size: 24.sp,
                    ),
                    onPressed: () {
                      print('Users Clicked');
                      navigateTo(context,
                          CommunityPage()); // استبدل `UsersPage` بالصفحة المناسبة
                    },
                  ),
                ],
              ),
              SizedBox(width: 10.w), // مسافة بين الأزرار
            ],
          ),
        ),
        actions: [
          // IconButton(
          //   icon:
          //       Icon(Icons.person, color: AppColors.primaryColor, size: 24.sp),
          //   onPressed: () {
          //     print('Notifications Clicked');
          //     navigateTo(context, ProfilePage());
          //   },
          // ),
          Padding(
            padding: EdgeInsets.only(right: 16.w),
            child: SvgPicture.asset(
              './lib/assets/logo.svg', // Replace with your logo path
              height: 30.h,
            ),
          ),
        ],
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: EdgeInsets.symmetric(horizontal: 16.w),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Search Bar
              Row(
                children: [
                  Expanded(
                    child: TextField(
                      decoration: InputDecoration(
                        hintText: 'Search...',
                        filled: true,
                        fillColor: Color(0xFFF9F9F9),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12.r),
                          borderSide: BorderSide.none,
                        ),
                      ),
                    ),
                  ),
                  SizedBox(width: 12.w),
                  Container(
                    decoration: BoxDecoration(
                      color: AppColors.primaryColor,
                      borderRadius: BorderRadius.circular(12.r),
                    ),
                    padding: EdgeInsets.all(12.w),
                    child: Icon(CupertinoIcons.search,
                        color: Colors.white, size: 24.sp),
                  ),
                ],
              ),
              SizedBox(height: 20.h),

              // Action Buttons
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  _buildActionButton(
                    title: 'Buy Product',
                    icon: './lib/assets/icons/serv1.png',
                    onTap: () {
                      print('Buy Product Clicked');
                      navigateTo(context, ChatBuyProduct());
                    },
                  ),
                  _buildActionButton(
                    title: 'Reserve Expert',
                    icon: './lib/assets/icons/serv2.png',
                    onTap: () {
                      print('Reserve Expert Clicked');
                      navigateTo(context, ChatExpertPage());
                    },
                  ),
                  _buildActionButton(
                    title: 'Find a Salon',
                    icon: './lib/assets/icons/serv3.png',
                    onTap: () {
                      print('Find a Salon Clicked');
                      navigateTo(context, ChatSalonPage());
                    },
                  ),
                ],
              ),
              SizedBox(height: 20.h),

              // Banner
              ClipRRect(
                borderRadius: BorderRadius.circular(12.r),
                child: Image.asset(
                  './lib/assets/icons/banner.png', // Replace with your banner path
                  width: double.infinity,
                  fit: BoxFit.cover,
                ),
              ),
              SizedBox(height: 20.h),

              // Top Products Section
              Text(
                'Top Products',
                style: TextStyle(
                  fontSize: 18.sp,
                  fontWeight: FontWeight.bold,
                  color: Colors.black,
                ),
              ),
              SizedBox(height: 12.h),
              _buildProductList(context),

              SizedBox(height: 20.h),

              // New Products Section
              Text(
                'New Products',
                style: TextStyle(
                  fontSize: 18.sp,
                  fontWeight: FontWeight.bold,
                  color: Colors.black,
                ),
              ),
              SizedBox(height: 12.h),
              _buildProductList(context),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildActionButton({
    required String title,
    required String icon,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Column(
        children: [
          Container(
            padding: EdgeInsets.all(16.w),
            decoration: BoxDecoration(
              color: AppColors.primaryColor,
              borderRadius: BorderRadius.circular(12.r),
            ),
            child: Image.asset(
              icon, // Replace with your icon path
              height: 24.h,
              fit: BoxFit.contain,
            ),
          ),
          SizedBox(height: 8.h),
          Text(
            title,
            style: TextStyle(
              fontSize: 12.sp,
              fontWeight: FontWeight.bold,
              color: AppColors.primaryColor,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildProductList(context) {
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: Row(
        children: List.generate(
          5, // Number of products
          (index) => Padding(
            padding: EdgeInsets.only(right: 16.w),
            child: ProductCard(
              imageUrl:
                  './lib/assets/testProduct.png', // Replace with your product image
              title: 'SPONGE FREE EFF...',
              subtitle: 'Shine Repair',
              price: 3000.0,
              onAddToCart: () {
                navigateTo(context, CartPage());
              },
              onFavoriteToggle: () {
                navigateTo(context, WishlistPage());
                // print('Favorite Toggle for Product $index');
              },
              isFavorited: false,
            ),
          ),
        ),
      ),
    );
  }
}
