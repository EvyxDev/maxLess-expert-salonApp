import 'package:flutter/cupertino.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:maxless/core/component/custom-header.dart';
import 'package:maxless/core/constants/app_colors.dart';
import 'package:maxless/core/constants/widgets/custom_button.dart';

class OrderDetailsPage extends StatelessWidget {
  final bool isDelivered; // لتحديد حالة الطلب

  const OrderDetailsPage({
    Key? key,
    this.isDelivered = false,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header

          SizedBox(height: 20.h),

          CustomHeader(
            title: "Order Details",
            onBackPress: () {
              Navigator.pop(context);
            },
          ),
          SizedBox(height: 10.h),

          // Status Box
          Center(
            child: Container(
              width: 300.w,
              padding: EdgeInsets.symmetric(vertical: 16.h, horizontal: 12.w),
              decoration: BoxDecoration(
                color: AppColors.primaryColor,
                borderRadius: BorderRadius.circular(12.r),
              ),
              child: Column(
                children: [
                  Text(
                    "Thank you 👋",
                    style: TextStyle(
                      fontSize: 14.sp,
                      fontWeight: FontWeight.bold,
                      color: Colors.black,
                    ),
                  ),
                  SizedBox(height: 5.h),
                  Text(
                    isDelivered
                        ? "Your Order has been delivered"
                        : "We Received Your Order",
                    style: TextStyle(
                      fontSize: 20.sp,
                      fontWeight: FontWeight.w500,
                      color: AppColors.primaryColor,
                    ),
                  ),
                  SizedBox(height: 5.h),
                  Text(
                    "Order #2930541",
                    style: TextStyle(
                      fontSize: 12.sp,
                      fontWeight: FontWeight.w400,
                      color: AppColors.black,
                    ),
                  ),
                ],
              ),
            ),
          ),
          SizedBox(height: 10.h),

          // Cancel Order
          if (!isDelivered)
            Center(
              child: RichText(
                text: TextSpan(
                  text: "Do you want to cancel your order? ",
                  style: TextStyle(
                    fontSize: 12.sp,
                    color: Colors.grey, // النص الأساسي باللون الرمادي
                  ),
                  children: [
                    TextSpan(
                      text: "Cancel",
                      style: TextStyle(
                        fontSize: 12.sp,
                        color: AppColors.primaryColor,
                        fontWeight: FontWeight.bold,
                        decoration: TextDecoration.underline,
                      ),
                      recognizer: TapGestureRecognizer()
                        ..onTap = () {
                          // عرض نافذة التأكيد
                          showDialog(
                            context: context,
                            builder: (BuildContext context) {
                              return AlertDialog(
                                contentPadding: EdgeInsets.all(16.0),
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(15.r),
                                ),
                                content: Column(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    Text(
                                      "Are you sure you want to cancel this order?",
                                      textAlign: TextAlign.center,
                                      style: TextStyle(
                                        fontSize: 14.sp,
                                        fontWeight: FontWeight.bold,
                                        color: Colors.black,
                                      ),
                                    ),
                                    SizedBox(height: 20.h),
                                    Column(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceEvenly,
                                      children: [
                                        SizedBox(
                                          width: double
                                              .infinity, // عرض الزر بالكامل
                                          child: CustomElevatedButton(
                                            text: "Customer Service",
                                            color: AppColors.primaryColor,
                                            borderRadius: 10.r,
                                            textColor: Colors.white,
                                            onPressed: () {
                                              Navigator.pop(context);
                                              print("Customer Service");
                                            },
                                          ),
                                        ),
                                        SizedBox(height: 10.h),
                                        SizedBox(
                                          width: double
                                              .infinity, // عرض الزر بالكامل
                                          child: CustomElevatedButton(
                                            text: "Cancel",
                                            borderColor: AppColors.primaryColor,
                                            borderRadius: 10.r,
                                            color: Colors.white,
                                            textColor: AppColors.primaryColor,
                                            onPressed: () {
                                              Navigator.pop(context);
                                              print("Order Canceled");
                                            },
                                          ),
                                        ),
                                      ],
                                    ),
                                    SizedBox(height: 10.h),
                                    TextButton(
                                      onPressed: () {
                                        Navigator.pop(context);
                                        print("Or add product");
                                      },
                                      child: Text(
                                        "Or add product",
                                        style: TextStyle(
                                          fontSize: 12.sp,
                                          color: Colors.grey,
                                          decoration: TextDecoration.underline,
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              );
                            },
                          );
                        },
                    ),
                  ],
                ),
              ),
            ),

          SizedBox(height: 20.h),

          // Order Details Title
          Padding(
            padding: EdgeInsets.symmetric(horizontal: 16.w),
            child: Text(
              "Order Details",
              style: TextStyle(
                fontSize: 14.sp,
                fontWeight: FontWeight.bold,
                color: Colors.black,
              ),
            ),
          ),
          SizedBox(height: 10.h),

          // Order Details Box
          Padding(
            padding: EdgeInsets.symmetric(horizontal: 16.w),
            child: Container(
              decoration: BoxDecoration(
                border: Border.all(color: Colors.grey.shade300),
                borderRadius: BorderRadius.circular(10.r),
              ),
              child: Padding(
                padding: EdgeInsets.all(10.w),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _buildOrderItem("De_Piel", "300 LE", 1),
                    _buildOrderItem("Favelin", "500 LE", 1),
                    Divider(color: Colors.grey.shade300),
                    _buildSummaryRow("Subtotal", "800 LE"),
                    _buildSummaryRow("Shipping", "0 LE"),
                    Divider(color: Colors.grey.shade300),
                    _buildSummaryRow(
                      "Total Payment",
                      "800 LE",
                      isBold: true,
                      color: AppColors.primaryColor,
                    ),
                    SizedBox(height: 10.h),
                    _buildSummaryRow("Delivery in", "1 - 3 Days"),
                    _buildSummaryRow("Time", "15:24 - 15:39"),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // Widget for each order item
  Widget _buildOrderItem(String name, String price, int quantity) {
    return Padding(
      padding: EdgeInsets.symmetric(vertical: 5.h),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            "$quantity x $name",
            style: TextStyle(
              fontSize: 15.sp,
              fontWeight: FontWeight.w400,
              color: Colors.black,
            ),
          ),
          Text(
            price,
            style: TextStyle(
              fontSize: 15.sp,
              fontWeight: FontWeight.w400,
              color: Colors.black,
            ),
          ),
        ],
      ),
    );
  }

  // Widget for summary rows
  Widget _buildSummaryRow(String title, String value,
      {bool isBold = false, Color? color}) {
    return Padding(
      padding: EdgeInsets.symmetric(vertical: 5.h),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            title,
            style: TextStyle(
              fontSize: 15.sp,
              fontWeight: isBold ? FontWeight.bold : FontWeight.w400,
              color: color ?? Colors.black,
            ),
          ),
          Text(
            value,
            style: TextStyle(
              fontSize: 15.sp,
              fontWeight: isBold ? FontWeight.bold : FontWeight.w400,
              color: color ?? Colors.black,
            ),
          ),
        ],
      ),
    );
  }
}
