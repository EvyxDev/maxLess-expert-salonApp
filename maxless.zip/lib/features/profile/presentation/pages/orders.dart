import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:maxless/core/component/custom-header.dart';
import 'package:maxless/core/component/custom-order-card.dart';
import 'package:maxless/core/constants/app_colors.dart';
import 'package:maxless/core/constants/navigation.dart';
import 'package:maxless/features/profile/presentation/pages/order-details.dart';

class OrdersPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 3, // التابات: Completed, On Way, Canceled
      child: Scaffold(
        body: Column(
          children: [
            SizedBox(height: 20.h),

            CustomHeader(
              title: "Orders",
              onBackPress: () {
                Navigator.pop(context);
              },
            ),
            // TabBar
            Padding(
              padding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 10.h),
              child: Container(
                height: 50.h,
                decoration: BoxDecoration(
                  color: AppColors.primaryColor, // خلفية التابات
                  borderRadius: BorderRadius.circular(15.r),
                ),
                child: TabBar(
                  labelColor: AppColors.primaryColor,
                  unselectedLabelColor: Colors.white,
                  indicator: BoxDecoration(
                    color: Colors.white, // لون التاب المحدد
                    borderRadius: BorderRadius.circular(10.r),
                  ),
                  indicatorSize:
                      TabBarIndicatorSize.tab, // جعل المؤشر يأخذ عرض التاب
                  labelStyle: TextStyle(
                    fontSize: 14.sp,
                    fontWeight: FontWeight.bold,
                  ),
                  dividerColor: Colors.transparent,
                  dividerHeight: 0,

                  padding: EdgeInsets.symmetric(horizontal: 7.w, vertical: 7.h),
                  tabs: [
                    Tab(text: "Completed"),
                    Tab(text: "On Way"),
                    Tab(text: "Canceled"),
                  ],
                ),
              ),
            ),
            // TabBar Content
            Expanded(
              child: TabBarView(
                children: [
                  _buildOrderList([
                    {
                      "id": "#2930541",
                      "status": "Delivered",
                      "date": "Tuesday, 10th Dec, 5:00 pm",
                      "price": "800 LE",
                      "items": 4
                    },
                    {
                      "id": "etubjmcke1283hd",
                      "status": "Delivered",
                      "date": "Tuesday, 10th Dec, 5:00 pm",
                      "price": "800 LE",
                      "items": 4
                    },
                  ]),
                  _buildOrderList([
                    {
                      "id": "#2930542",
                      "status": "On Way",
                      "date": "Arrives between Dec 20, Dec 23",
                      "price": "800 LE",
                      "items": 4
                    },
                    {
                      "id": "etubjmcke1283hd",
                      "status": "On Way",
                      "date": "Arrives between Dec 20, Dec 23",
                      "price": "800 LE",
                      "items": 4
                    },
                  ]),
                  _buildOrderList([
                    {
                      "id": "etubjmcke1283hd",
                      "status": "Canceled",
                      "date": "",
                      "price": "800 LE",
                      "items": 4
                    },
                  ]),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildOrderList(List<Map<String, dynamic>> orders) {
    return ListView.separated(
      padding: EdgeInsets.all(16.w),
      itemCount: orders.length,
      separatorBuilder: (context, index) =>
          Divider(color: Colors.grey.shade300),
      itemBuilder: (context, index) {
        final order = orders[index];
        return GestureDetector(
          onTap: () {
            navigateTo(
                context,
                OrderDetailsPage(
                  isDelivered: false,
                ));
          },
          child: OrderCard(
            imageUrl: './lib/assets/testProducts.png', // صورة المنتج
            orderId: order["id"],
            status: order["status"],
            date: order["date"],
            price: order["price"],
            items: order["items"],
          ),
        );
      },
    );
  }
}
