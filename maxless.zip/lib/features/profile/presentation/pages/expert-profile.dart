import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:maxless/core/component/custom-header.dart';
import 'package:maxless/core/constants/app_colors.dart';
import 'package:maxless/core/constants/widgets/custom_button.dart';

class ExpertProfilePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(height: 20.h),
            CustomHeader(
              title: "Community",
              onBackPress: () {
                Navigator.pop(context);
              },
            ),
            SizedBox(height: 10.h),
            Padding(
              padding: EdgeInsets.all(16.w),

              // padding: const EdgeInsets.all(8.0),
              child: Column(
                children: [
                  Center(
                    child: Column(
                      children: [
                        CircleAvatar(
                          radius: 40.r,
                          backgroundImage: AssetImage('lib/assets/expert.png'),
                        ),
                        SizedBox(height: 10.h),
                        Text(
                          "May Ahmed",
                          style: TextStyle(
                            fontSize: 18.sp,
                            fontWeight: FontWeight.bold,
                            color: AppColors.primaryColor,
                          ),
                        ),
                        Row(
                          mainAxisSize: MainAxisSize.min,
                          children: List.generate(5, (index) {
                            return Icon(Icons.star,
                                color: index < 4 ? Colors.amber : Colors.grey,
                                size: 16.sp);
                          }),
                        ),
                        SizedBox(height: 10.h),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  "Experience",
                                  style: TextStyle(
                                      color: Colors.grey, fontSize: 14.sp),
                                ),
                                SizedBox(height: 4.h),
                                Text(
                                  "Reviews",
                                  style: TextStyle(
                                      color: Colors.grey, fontSize: 14.sp),
                                ),
                              ],
                            ),
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.end,
                              children: [
                                Text(
                                  "2 years",
                                  style: TextStyle(
                                      color: Colors.grey, fontSize: 14.sp),
                                ),
                                SizedBox(height: 4.h),
                                Text(
                                  "56",
                                  style: TextStyle(
                                      color: Colors.grey, fontSize: 14.sp),
                                ),
                              ],
                            ),
                          ],
                        ),
                        SizedBox(height: 12.h), // مسافة بين النص والخط الفاصل
                        Divider(
                          thickness: 1,
                          color: Colors.grey.shade300, // لون الخط
                        ),
                      ],
                    ),
                  ),
                  Text("Posts",
                      style: TextStyle(
                          fontSize: 16.sp, fontWeight: FontWeight.bold)),
                  SizedBox(height: 10.h),
                  ...List.generate(3, (index) => _buildPostCard()),
                  SizedBox(height: 70.h),
                ],
              ),
            )
          ],
        ),
      ),
      floatingActionButton: Padding(
        padding: EdgeInsets.only(
            bottom: 20.h, left: 20.w, right: 20.w), // لتجنب تغطية المحتوى
        child: CustomElevatedButton(
          text: "Reserve Appointment",
          borderRadius: 10,
          color: AppColors.primaryColor,
          textColor: Colors.white,
          onPressed: () {
            // Save Changes Logic
          },
        ),
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
    );
  }

  Widget _buildPostCard() {
    return Container(
      decoration: BoxDecoration(
        color: Color(0xffFBFBFB),
        // border: Border.all(color: AppColors.primaryColor, width: 1.w),
        borderRadius: BorderRadius.circular(10.r),
      ),
      margin: EdgeInsets.only(bottom: 16.h),
      child: Padding(
        padding: EdgeInsets.all(16.w),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                CircleAvatar(
                  radius: 20.r,
                  backgroundImage: AssetImage('./lib/assets/expert.png'),
                ),
                SizedBox(width: 10.w),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "May Ahmed",
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 14.sp,
                      ),
                    ),
                    Text(
                      "Nasr City, Cairo",
                      style: TextStyle(
                        color: Colors.grey,
                        fontSize: 12.sp,
                      ),
                    ),
                  ],
                ),
                Spacer(),
                Text(
                  "6 hours ago",
                  style: TextStyle(
                    color: Colors.grey,
                    fontSize: 12.sp,
                  ),
                ),
              ],
            ),
            SizedBox(height: 12.h),
            ClipRRect(
              borderRadius: BorderRadius.circular(8.r),
              child: Image.asset(
                './lib/assets/post.png',
                height: 200.h,
                width: double.infinity,
                fit: BoxFit.cover,
              ),
            ),
            SizedBox(height: 12.h),
            Text(
              "This serum treats hair loss, damage, and frizz. It helps prevent hair loss and protects hair from heat damage by creating",
              style: TextStyle(
                fontSize: 14.sp,
                height: 1.5,
              ),
            ),
            SizedBox(height: 12.h),
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                Icon(
                  CupertinoIcons.heart,
                  color: AppColors.primaryColor,
                  size: 20.sp,
                ),
                SizedBox(width: 5.w),
                Text(
                  "100",
                  style: TextStyle(
                    color: AppColors.primaryColor,
                    fontSize: 14.sp,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
