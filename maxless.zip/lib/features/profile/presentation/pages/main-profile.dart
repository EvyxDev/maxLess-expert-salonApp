import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:maxless/core/component/custom-header.dart';
import 'package:maxless/core/component/profile-list.dart';
import 'package:maxless/core/constants/app_colors.dart';
import 'package:maxless/core/constants/navigation.dart';
import 'package:maxless/core/constants/widgets/custom_button.dart';
import 'package:maxless/features/auth/presentation/pages/login.dart';
import 'package:maxless/features/profile/presentation/pages/community.dart';
import 'package:maxless/features/profile/presentation/pages/edit-profile.dart';
import 'package:maxless/features/profile/presentation/pages/massages.dart';
import 'package:maxless/features/profile/presentation/pages/orders.dart';
import 'package:maxless/features/profile/presentation/pages/wallet.dart';
import 'package:maxless/features/reservation/presentation/pages/reservations.dart';

class ProfilePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          SizedBox(height: 20.h),
          CustomHeader(
            title: "Profile",
            onBackPress: () {
              Navigator.pop(context);
            },
          ),
          Expanded(
            child: SingleChildScrollView(
              padding: EdgeInsets.all(16.w),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Profile Header
                  GestureDetector(
                    onTap: () {
                      navigateTo(context, EditProfilePage());
                    },
                    child: Row(
                      children: [
                        CircleAvatar(
                          radius: 40.r,
                          backgroundImage:
                              AssetImage('./lib/assets/profile.png'),
                        ),
                        SizedBox(width: 16.w),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              "Sara Ali",
                              style: TextStyle(
                                fontSize: 16.sp,
                                fontWeight: FontWeight.bold,
                                color: Colors.black,
                              ),
                            ),
                            SizedBox(height: 4.h),
                            Text(
                              "SaraAli@gmail.com",
                              style: TextStyle(
                                fontSize: 14.sp,
                                color: Colors.grey,
                              ),
                            ),
                          ],
                        ),
                        Spacer(),
                        IconButton(
                          icon: Icon(CupertinoIcons.pen,
                              color: AppColors.primaryColor),
                          onPressed: () {
                            navigateTo(context, EditProfilePage());
                          },
                        ),
                      ],
                    ),
                  ),
                  SizedBox(height: 20.h),

                  // Points Section
                  Container(
                    padding: EdgeInsets.all(12.w),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(12.r),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.grey.shade200,
                          blurRadius: 6,
                          offset: Offset(0, 2),
                        ),
                      ],
                    ),
                    child: GestureDetector(
                      onTap: () {
                        showModalBottomSheet(
                          context: context,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.vertical(
                              top: Radius.circular(20.r),
                            ),
                          ),
                          isScrollControlled: true,
                          builder: (context) {
                            return DraggableScrollableSheet(
                              initialChildSize: 0.5,
                              maxChildSize: 0.7,
                              minChildSize: 0.3,
                              expand: false,
                              builder: (_, controller) {
                                return SingleChildScrollView(
                                  controller: controller,
                                  child: Padding(
                                    padding: EdgeInsets.all(16.w),
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          "Easily collect points",
                                          style: TextStyle(
                                            fontSize: 16.sp,
                                            fontWeight: FontWeight.bold,
                                            color: AppColors.primaryColor,
                                          ),
                                        ),
                                        SizedBox(height: 10.h),
                                        Text(
                                          "Accumulate points with every successfully completed session.",
                                          style: TextStyle(
                                            fontSize: 14.sp,
                                            color: AppColors.primaryColor,
                                          ),
                                        ),
                                        SizedBox(height: 20.h),
                                        _buildPointBenefit(
                                            "Redeem your points for rewards."),
                                        _buildPointBenefit(
                                            "Get free hair care products."),
                                        _buildPointBenefit(
                                            "Enjoy a complimentary session."),
                                        _buildPointBenefit(
                                            "Get a discount on hair care products and sessions."),
                                        SizedBox(height: 20.h),
                                        Text(
                                          "All directly through the app: Redeeming points is quick and easy through the rewards section.",
                                          style: TextStyle(
                                            fontSize: 12.sp,
                                            color: Colors.grey,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                );
                              },
                            );
                          },
                        );
                      },
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Icon(
                                CupertinoIcons.star_circle,
                                color: AppColors.primaryColor,
                                size: 20.sp,
                              ),
                              SizedBox(width: 10.w),
                              Text(
                                "200 Points",
                                style: TextStyle(
                                  fontSize: 14.sp,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.black,
                                ),
                              ),
                            ],
                          ),
                          SizedBox(height: 4.h),
                          Text(
                            "Total points earned",
                            style: TextStyle(
                              fontSize: 12.sp,
                              color: Colors.grey,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),

                  SizedBox(height: 20.h),

                  // Services Section
                  Text(
                    "Services",
                    style: TextStyle(
                      fontSize: 16.sp,
                      fontWeight: FontWeight.bold,
                      color: Colors.black,
                    ),
                  ),
                  SizedBox(height: 10.h),
                  ProfileOption(
                    icon: CupertinoIcons.bag,
                    title: "Orders",
                    onTap: () {
                      navigateTo(context, OrdersPage());
                    },
                  ),
                  ProfileOption(
                    icon: CupertinoIcons.calendar_today,
                    title: "Reservations",
                    onTap: () {
                      navigateTo(context, ReservationsPage());
                    },
                  ),
                  ProfileOption(
                    icon: CupertinoIcons.location_circle,
                    title: "Tracking Order",
                    onTap: () {
                      // Navigate to Tracking Order
                    },
                  ),
                  ProfileOption(
                    icon: CupertinoIcons.person_3,
                    title: "Community",
                    onTap: () {
                      navigateTo(context, CommunityPage());
                    },
                  ),
                  SizedBox(height: 20.h),

                  // Account Section
                  Text(
                    "Account",
                    style: TextStyle(
                      fontSize: 16.sp,
                      fontWeight: FontWeight.bold,
                      color: Colors.black,
                    ),
                  ),
                  SizedBox(height: 10.h),
                  ProfileOption(
                    icon: CupertinoIcons.chat_bubble,
                    title: "Messages",
                    onTap: () {
                      navigateTo(context, MessagesPage());
                    },
                  ),
                  ProfileOption(
                    icon: CupertinoIcons.question_circle,
                    title: "Support",
                    onTap: () {
                      // Navigate to Support
                    },
                  ),
                  ProfileOption(
                    icon: CupertinoIcons.creditcard,
                    title: "Wallet",
                    onTap: () {
                      navigateTo(context, WalletPage());
                    },
                  ),
                  ProfileOption(
                    icon: CupertinoIcons.lock,
                    title: "Privacy",
                    onTap: () {
                      // Navigate to Privacy
                    },
                  ),
                  ProfileOption(
                    icon: CupertinoIcons.arrow_right_square,
                    title: "Logout",
                    textColor: AppColors.primaryColor,
                    onTap: () {
                      showDialog(
                        context: context,
                        builder: (context) => AlertDialog(
                          alignment: Alignment.center,
                          title: Text(
                            "Are you sure you want to logout?",
                            textAlign: TextAlign.center,
                            style: TextStyle(
                                fontSize: 15.sp,
                                fontWeight: FontWeight.w400,
                                color: Colors.black),
                          ),
                          shape: ContinuousRectangleBorder(
                              borderRadius: BorderRadius.circular(20)),
                          actions: [
                            Row(
                              children: [
                                Expanded(
                                  child: CustomElevatedButton(
                                    text: "Yes",
                                    color: Colors.white,
                                    borderRadius: 10,
                                    borderColor: AppColors.primaryColor,
                                    textColor: AppColors.primaryColor,
                                    onPressed: () {
                                      navigateTo(context, Login());
                                    },
                                  ),
                                ),
                                SizedBox(width: 10.h), // مسافة بين الأزرار

                                Expanded(
                                  child: CustomElevatedButton(
                                    text: "No",
                                    borderRadius: 10,
                                    color: AppColors.primaryColor,
                                    textColor: Colors.white,
                                    onPressed: () {
                                      Navigator.pop(context);
                                      // Navigator.pop(context); // إغلاق المودال
                                    },
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      );
                    },
                  ),
                  SizedBox(height: 20.h),

                  // Footer Links
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Icon(
                            CupertinoIcons
                                .lock_shield_fill, // Icon for Privacy Policy
                            color: Colors.grey,
                            size: 16.sp,
                          ),
                          SizedBox(width: 5.w),
                          GestureDetector(
                            onTap: () {
                              // Navigate to Privacy Policy
                            },
                            child: Text(
                              "Privacy Policy",
                              style: TextStyle(
                                fontSize: 12.sp,
                                color: Colors.grey,
                                fontWeight: FontWeight.w400,
                              ),
                            ),
                          ),
                        ],
                      ),
                      SizedBox(height: 10.h),
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Icon(
                            CupertinoIcons
                                .question_circle_fill, // Icon for Help
                            color: Colors.grey,
                            size: 16.sp,
                          ),
                          SizedBox(width: 5.w),
                          GestureDetector(
                            onTap: () {
                              // Navigate to Help
                            },
                            child: Text(
                              "Help",
                              style: TextStyle(
                                fontSize: 12.sp,
                                color: Colors.grey,
                                fontWeight: FontWeight.w400,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),

                  SizedBox(height: 20.h),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPointBenefit(String text) {
    return Padding(
      padding: EdgeInsets.only(bottom: 10.h),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SvgPicture.asset("./lib/assets/icons/star.svg"),
          SizedBox(width: 10.w),
          Expanded(
            child: Text(
              text,
              style: TextStyle(
                fontSize: 14.sp,
                color: Colors.black87,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
