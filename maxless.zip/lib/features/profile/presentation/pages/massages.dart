import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:maxless/core/component/custom-header.dart';
import 'package:maxless/core/constants/app_colors.dart';
import 'package:maxless/core/constants/navigation.dart';
import 'package:maxless/features/chatting/presentation/pages/buy-product/buy-product.dart';
import 'package:maxless/features/chatting/presentation/pages/customer-service/customer-service-chat.dart';
import 'package:maxless/features/chatting/presentation/pages/expert/expert-chat.dart';
import 'package:maxless/features/chatting/presentation/pages/salon/salon-chat.dart';

class MessagesPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        body: Column(
          children: [
            SizedBox(height: 20.h),
            CustomHeader(
              title: "Messages",
              onBackPress: () {
                Navigator.pop(context);
              },
            ),
            Padding(
              padding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 10.h),
              child: Container(
                height: 50.h,
                decoration: BoxDecoration(
                  color: AppColors.primaryColor, // خلفية التابات
                  borderRadius: BorderRadius.circular(15.r),
                ),
                child: TabBar(
                  labelColor: AppColors.primaryColor,
                  unselectedLabelColor: Colors.white,
                  indicator: BoxDecoration(
                    color: Colors.white, // لون التاب المحدد
                    borderRadius: BorderRadius.circular(10.r),
                  ),
                  indicatorSize:
                      TabBarIndicatorSize.tab, // جعل المؤشر يأخذ عرض التاب
                  labelStyle: TextStyle(
                    fontSize: 14.sp,
                    fontWeight: FontWeight.bold,
                  ),
                  dividerColor: Colors.transparent,
                  dividerHeight: 0,

                  padding: EdgeInsets.symmetric(horizontal: 7.w, vertical: 7.h),
                  tabs: [
                    Tab(text: "Orders"),
                    Tab(text: "Customer Service"),
                  ],
                ),
              ),
            ),
            Expanded(
              child: TabBarView(
                children: [
                  // محتوى تبويب Orders
                  Column(
                    children: [
                      // مربع البحث
                      Padding(
                        padding: EdgeInsets.all(16.w),
                        child: Row(
                          children: [
                            Expanded(
                              child: TextField(
                                decoration: InputDecoration(
                                  hintText: "Search...",
                                  hintStyle: TextStyle(
                                    fontSize: 14.sp,
                                    color: Colors.grey,
                                  ),
                                  filled: true,
                                  fillColor: Colors.grey.shade200,
                                  border: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(10.r),
                                    borderSide: BorderSide.none,
                                  ),
                                ),
                              ),
                            ),
                            SizedBox(width: 10.w),
                            GestureDetector(
                              onTap: () {
                                // تنفيذ البحث
                              },
                              child: Container(
                                height: 40.h,
                                width: 40.h,
                                decoration: BoxDecoration(
                                  color: AppColors.primaryColor,
                                  borderRadius: BorderRadius.circular(10.r),
                                ),
                                child: Icon(
                                  CupertinoIcons.search,
                                  color: Colors.white,
                                  size: 20.sp,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      // قائمة الرسائل
                      Expanded(
                        child: _buildMessagesList([
                          {"title": "Buy product", "subtitle": "Lorem Ipsum"},
                          {
                            "title": "Reserve an expert",
                            "subtitle": "Lorem Ipsum"
                          },
                          {"title": "Find salon", "subtitle": "Lorem Ipsum"},
                        ]),
                      ),
                    ],
                  ),
                  // محتوى تبويب Customer Service
                  _buildMessagesList([
                    {"title": "Customer Service", "subtitle": "Lorem Ipsum"},
                  ]),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildMessagesList(List<Map<String, String>> messages) {
    return ListView.separated(
      padding: EdgeInsets.all(16.w),
      itemCount: messages.length,
      separatorBuilder: (context, index) =>
          Divider(color: Colors.grey.shade300),
      itemBuilder: (context, index) {
        final message = messages[index];
        return GestureDetector(
          onTap: () {
            // تخصيص الإجراء حسب العنصر
            if (message["title"] == "Reserve an expert") {
              print("Action for Reserve an expert");
              navigateTo(context, ChatExpertPage());
            } else if (message["title"] == "Find salon") {
              print("Action for Find salon");
              navigateTo(context, ChatSalonPage());
            } else if (message["title"] == "Buy product") {
              print("Action for Buy product");
              navigateTo(context, ChatBuyProduct());
            } else {
              print("Default action for ${message["title"]}");
              navigateTo(context, CustomerServiceChat());
            }
          },
          child: ListTile(
            leading: ClipRRect(
              borderRadius: BorderRadius.circular(10.w),
              child: SvgPicture.asset(
                './lib/assets/icons/maxIcon.svg',
                height: 40.h,
                width: 40.w,
              ),
            ),
            title: Text(
              message["title"]!,
              style: TextStyle(fontSize: 14.sp, fontWeight: FontWeight.bold),
            ),
            subtitle: Text(
              message["subtitle"]!,
              style: TextStyle(fontSize: 12.sp, color: Colors.grey),
            ),
          ),
        );
      },
    );
  }
}
