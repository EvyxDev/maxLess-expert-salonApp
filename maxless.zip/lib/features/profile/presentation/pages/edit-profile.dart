import 'dart:async';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:maxless/core/component/custom-header.dart';
import 'package:maxless/core/constants/app_colors.dart';
import 'package:maxless/core/constants/widgets/custom_button.dart';
import 'package:maxless/core/constants/widgets/custom_text_form_field.dart';

class EditProfilePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          SizedBox(height: 20.h),
          CustomHeader(
            title: "Edit Profile",
            onBackPress: () {
              Navigator.pop(context);
            },
          ),
          Expanded(
            child: SingleChildScrollView(
              padding: EdgeInsets.all(16.w),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Profile Picture and Name
                  Center(
                    child: Column(
                      children: [
                        CircleAvatar(
                          radius: 40.r,
                          backgroundImage:
                              AssetImage('./lib/assets/profile.png'),
                        ),
                        SizedBox(height: 10.h),
                        Text(
                          "Sara Ali",
                          style: TextStyle(
                            fontSize: 16.sp,
                            fontWeight: FontWeight.bold,
                            color: Colors.black,
                          ),
                        ),
                        Text(
                          "SaraAli@gmail.com",
                          style: TextStyle(
                            fontSize: 14.sp,
                            color: Colors.grey,
                          ),
                        ),
                      ],
                    ),
                  ),
                  SizedBox(height: 20.h),

                  // Editable Fields
                  _buildEditableField(
                      context, "Username", "Sara Ali", Icons.edit),
                  _buildEditableField(
                      context, "Email", "SaraAli@gmail.com", Icons.edit),
                  _buildEditableField(
                      context, "Password", "********", Icons.lock),
                  _buildEditableField(
                      context, "Mobile", "+02 | 01012457898", Icons.phone),
                  _buildEditableField(
                      context, "Language", "Arabic", Icons.language),
                  _buildEditableField(
                      context, "Address 1", "Home", Icons.location_on),

                  // Add New Address Link
                  Padding(
                    padding: EdgeInsets.symmetric(vertical: 10.h),
                    child: Text(
                      "+ Add New Address",
                      style: TextStyle(
                        fontSize: 14.sp,
                        color: AppColors.primaryColor,
                        decoration: TextDecoration.underline,
                      ),
                    ),
                  ),

                  // Delete Account Link
                  GestureDetector(
                    onTap: () {
                      showDialog(
                        context: context,
                        builder: (context) => AlertDialog(
                          alignment: Alignment.center,
                          title: Text(
                            "Are you sure you want to delete your account?",
                            textAlign: TextAlign.center,
                            style: TextStyle(
                                fontSize: 15.sp,
                                fontWeight: FontWeight.w400,
                                color: Colors.black),
                          ),
                          shape: ContinuousRectangleBorder(
                              borderRadius: BorderRadius.circular(20)),
                          actions: [
                            Row(
                              children: [
                                Expanded(
                                  child: CustomElevatedButton(
                                    text: "Yes",
                                    color: Colors.white,
                                    borderRadius: 10,
                                    borderColor: AppColors.primaryColor,
                                    textColor: AppColors.primaryColor,
                                    onPressed: () {
                                      Navigator.pop(
                                          context); // Close the dialog
                                    },
                                  ),
                                ),
                                SizedBox(width: 10.h), // مسافة بين الأزرار

                                Expanded(
                                  child: CustomElevatedButton(
                                    text: "No",
                                    borderRadius: 10,
                                    color: AppColors.primaryColor,
                                    textColor: Colors.white,
                                    onPressed: () {
                                      Navigator.pop(context);
                                      // Navigator.pop(context); // إغلاق المودال
                                    },
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      );
                    },
                    child: Text(
                      "Delete Account",
                      style: TextStyle(
                        fontSize: 14.sp,
                        color: AppColors.primaryColor,
                        decoration: TextDecoration.underline,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
          SizedBox(height: 70.h),
        ],
      ),
      floatingActionButton: Padding(
        padding: EdgeInsets.only(
            bottom: 20.h, left: 20.w, right: 20.w), // لتجنب تغطية المحتوى
        child: CustomElevatedButton(
          text: "Save Changes",
          borderRadius: 10,
          color: AppColors.primaryColor,
          textColor: Colors.white,
          onPressed: () {
            // Save Changes Logic
          },
        ),
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
    );
  }

  Widget _buildEditableField(
      BuildContext context, String label, String value, IconData icon) {
    return GestureDetector(
      onTap: () {
        _showBottomSheet(context, label); // عرض الـ Bottom Sheet
      },
      child: Padding(
        padding: EdgeInsets.symmetric(vertical: 10.h),
        child: Container(
          padding: EdgeInsets.symmetric(vertical: 10.h, horizontal: 16.w),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(12.r),
            border: Border.all(
              color: Colors.grey.shade300, // لون الحدود
            ),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    label,
                    style: TextStyle(
                      fontSize: 12.sp,
                      color: Colors.grey,
                    ),
                  ),
                  SizedBox(height: 5.h),
                  Text(
                    value,
                    style: TextStyle(
                      fontSize: 14.sp,
                      fontWeight: FontWeight.bold,
                      color: Colors.black,
                    ),
                  ),
                ],
              ),
              Icon(CupertinoIcons.pen, color: Colors.grey, size: 20.sp),
            ],
          ),
        ),
      ),
    );
  }

  void _showBottomSheet(BuildContext context, String fieldType) {
    showModalBottomSheet(
      context: context,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(
          top: Radius.circular(20.r),
        ),
      ),
      isScrollControlled: true,
      builder: (BuildContext context) {
        return Padding(
          padding: EdgeInsets.only(
            top: 20.h,
            left: 20.w,
            right: 20.w,
            bottom: MediaQuery.of(context).viewInsets.bottom,
          ),
          child: _buildSheetContent(context, fieldType), // إضافة الوسيطين هنا
        );
      },
    );
  }

  Widget _buildSheetContent(BuildContext context, String fieldType) {
    switch (fieldType) {
      case "Username":
        return _buildUsernameField();
      case "Email":
        return _buildEmailField(context);
      case "Password":
        return _buildPasswordField();
      case "Mobile":
        return _buildMobileField(context);
      case "Address":
        return _buildAddressField();
      default:
        return SizedBox.shrink();
    }
  }

// الحقول المختلفة
  Widget _buildUsernameField() {
    return Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          "Change Username",
          style: TextStyle(
            fontSize: 16.sp,
            fontWeight: FontWeight.bold,
            color: Colors.black,
          ),
        ),
        SizedBox(height: 10.h),
        TextField(
          decoration: InputDecoration(
            hintText: "Enter New Username",
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(10.r),
            ),
          ),
        ),
        SizedBox(height: 20.h),
        CustomElevatedButton(
          text: "Save",
          borderRadius: 10,
          color: AppColors.primaryColor,
          textColor: Colors.white,
          onPressed: () {
            // Save logic here
          },
        ),
      ],
    );
  }

  Widget _buildEmailField(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          "Change Email",
          style: TextStyle(
            fontSize: 16.sp,
            fontWeight: FontWeight.bold,
            color: Colors.black,
          ),
        ),
        SizedBox(height: 10.h),
        CustomTextFormField(
          hintText: "Enter New Email",
          borderRadius: 10.r,
        ),
        SizedBox(height: 20.h),
        CustomElevatedButton(
          text: "Continue",
          borderRadius: 10,
          color: AppColors.primaryColor,
          textColor: Colors.white,
          onPressed: () {
            Navigator.pop(context);
            _showOtpVerification(context, "Email"); // عرض OTP
          },
        ),
      ],
    );
  }

  Widget _buildPasswordField() {
    return Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          "Change Password",
          style: TextStyle(
            fontSize: 16.sp,
            fontWeight: FontWeight.bold,
            color: Colors.black,
          ),
        ),
        SizedBox(height: 10.h),
        CustomTextFormField(
          borderRadius: 12.r,
          labelText: 'Password',
          hintText: 'Enter New Password',
          obscureText: true,
          suffixIcon: Icon(
            CupertinoIcons.eye_slash,
            color: AppColors.grey,
            size: 20.sp,
          ),
        ),
        SizedBox(height: 20.h),
        CustomElevatedButton(
          text: "Continue",
          borderRadius: 10,
          color: AppColors.primaryColor,
          textColor: Colors.white,
          onPressed: () {
            // Continue logic here
          },
        ),
      ],
    );
  }

  Widget _buildMobileField(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          "Change Mobile",
          style: TextStyle(
            fontSize: 16.sp,
            fontWeight: FontWeight.bold,
            color: Colors.black,
          ),
        ),
        SizedBox(height: 10.h),
        CustomTextFormField(
          hintText: "Enter New Mobile",
          borderRadius: 10.r,
        ),
        SizedBox(height: 20.h),
        CustomElevatedButton(
          text: "Continue",
          borderRadius: 10,
          color: AppColors.primaryColor,
          textColor: Colors.white,
          onPressed: () {
            Navigator.pop(context);
            _showOtpVerification(context, "Mobile"); // عرض OTP
          },
        ),
      ],
    );
  }

  Widget _buildAddressField() {
    return Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          "Change Address",
          style: TextStyle(
            fontSize: 16.sp,
            fontWeight: FontWeight.bold,
            color: Colors.black,
          ),
        ),
        SizedBox(height: 10.h),
        CustomTextFormField(
          hintText: "Enter New Address",
          borderRadius: 10.r,
        ),
        SizedBox(height: 20.h),
        CustomElevatedButton(
          text: "Continue",
          borderRadius: 10,
          color: AppColors.primaryColor,
          textColor: Colors.white,
          onPressed: () {
            // Continue logic here
          },
        ),
      ],
    );
  }

// باقي الحقول بنفس الطريقة
}

void _showOtpVerification(BuildContext context, String fieldType) {
  showModalBottomSheet(
    context: context,
    shape: RoundedRectangleBorder(
      borderRadius: BorderRadius.vertical(
        top: Radius.circular(20.r),
      ),
    ),
    isScrollControlled: true,
    builder: (context) => _OtpVerificationSheet(fieldType: fieldType),
  );
}

class _OtpVerificationSheet extends StatefulWidget {
  final String fieldType;

  const _OtpVerificationSheet({Key? key, required this.fieldType})
      : super(key: key);

  @override
  State<_OtpVerificationSheet> createState() => __OtpVerificationSheetState();
}

class __OtpVerificationSheetState extends State<_OtpVerificationSheet> {
  int countdown = 20;
  bool showResendButton = false;
  Timer? timer;

  @override
  void initState() {
    super.initState();
    startCountdown();
  }

  @override
  void dispose() {
    timer?.cancel();
    super.dispose();
  }

  void startCountdown() {
    timer = Timer.periodic(Duration(seconds: 1), (timer) {
      if (countdown == 0) {
        timer.cancel();
        setState(() {
          showResendButton = true;
        });
      } else {
        setState(() {
          countdown--;
        });
      }
    });
  }

  void _showEmailBottomSheet(BuildContext context) {
    showModalBottomSheet(
      context: context,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(
          top: Radius.circular(20.r),
        ),
      ),
      isScrollControlled: true,
      builder: (context) {
        return Padding(
          padding: EdgeInsets.only(
            top: 20.h,
            left: 20.w,
            right: 20.w,
            bottom: MediaQuery.of(context).viewInsets.bottom,
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                "Change Email",
                style: TextStyle(
                  fontSize: 16.sp,
                  fontWeight: FontWeight.bold,
                  color: Colors.black,
                ),
              ),
              SizedBox(height: 10.h),
              CustomTextFormField(
                hintText: "Enter New Email",
                borderRadius: 10.r,
              ),
              SizedBox(height: 20.h),
              CustomElevatedButton(
                text: "Continue",
                borderRadius: 10,
                color: AppColors.primaryColor,
                textColor: Colors.white,
                onPressed: () {
                  Navigator.pop(context);
                  _showOtpVerification(context, "Email");
                },
              ),
            ],
          ),
        );
      },
    );
  }

  void _showMobileBottomSheet(BuildContext context) {
    showModalBottomSheet(
      context: context,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(
          top: Radius.circular(20.r),
        ),
      ),
      isScrollControlled: true,
      builder: (context) {
        return Padding(
          padding: EdgeInsets.only(
            top: 20.h,
            left: 20.w,
            right: 20.w,
            bottom: MediaQuery.of(context).viewInsets.bottom,
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                "Change Mobile",
                style: TextStyle(
                  fontSize: 16.sp,
                  fontWeight: FontWeight.bold,
                  color: Colors.black,
                ),
              ),
              SizedBox(height: 10.h),
              CustomTextFormField(
                hintText: "Enter New Mobile",
                borderRadius: 10.r,
              ),
              SizedBox(height: 20.h),
              CustomElevatedButton(
                text: "Continue",
                borderRadius: 10,
                color: AppColors.primaryColor,
                textColor: Colors.white,
                onPressed: () {
                  Navigator.pop(context);
                  _showOtpVerification(context, "Mobile");
                },
              ),
            ],
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(
        top: 20.h,
        left: 20.w,
        right: 20.w,
        bottom: MediaQuery.of(context).viewInsets.bottom,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              GestureDetector(
                onTap: () {
                  Navigator.pop(context); // إغلاق الشيت الحالي
                  Future.delayed(Duration(milliseconds: 200), () {
                    // عرض الشيت السابق
                    if (widget.fieldType == "Email") {
                      _showEmailBottomSheet(context);
                    } else if (widget.fieldType == "Mobile") {
                      _showMobileBottomSheet(context);
                    }
                  });
                },
                child: Icon(
                  CupertinoIcons.chevron_left,
                  color: Colors.black,
                  size: 24.sp,
                ),
              ),
              SizedBox(width: 10.w),
              Text(
                widget.fieldType == "Mobile"
                    ? "Please check your SMS"
                    : "Please check your Email",
                style: TextStyle(
                  fontSize: 16.sp,
                  fontWeight: FontWeight.bold,
                  color: Colors.black,
                ),
              ),
            ],
          ),
          SizedBox(height: 10.h),
          Text(
            widget.fieldType == "Mobile"
                ? "We've sent you a code to +02*******55"
                : "We've sent you a code to Example@gmail.com",
            style: TextStyle(
              fontSize: 14.sp,
              color: Colors.grey,
            ),
          ),
          SizedBox(height: 20.h),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: List.generate(4, (index) {
              return Container(
                width: 50.w,
                height: 50.h,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(10.r),
                  border: Border.all(color: Colors.grey),
                ),
                child: Center(
                  child: TextField(
                    textAlign: TextAlign.center,
                    keyboardType: TextInputType.number,
                    style: TextStyle(
                      fontSize: 18.sp,
                      fontWeight: FontWeight.bold,
                      color: Colors.black,
                    ),
                    decoration: InputDecoration(
                      border: InputBorder.none,
                    ),
                  ),
                ),
              );
            }),
          ),
          SizedBox(height: 20.h),
          CustomElevatedButton(
            text: "Verify",
            borderRadius: 10,
            color: AppColors.primaryColor,
            textColor: Colors.white,
            icon: Icon(
              CupertinoIcons.arrow_right,
              size: 16.sp,
              color: Colors.white,
            ),
            onPressed: () {
              // Verify logic here
            },
          ),
          SizedBox(height: 10.h),
          Center(
            child: showResendButton
                ? GestureDetector(
                    onTap: () {
                      setState(() {
                        countdown = 20;
                        showResendButton = false;
                      });
                      startCountdown();
                    },
                    child: Text(
                      "Resend Code",
                      style: TextStyle(
                        fontSize: 12.sp,
                        color: AppColors.primaryColor,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  )
                : Text(
                    "Send code again in 00:${countdown.toString().padLeft(2, '0')}",
                    style: TextStyle(
                      fontSize: 12.sp,
                      color: AppColors.primaryColor,
                    ),
                  ),
          ),
        ],
      ),
    );
  }
}
