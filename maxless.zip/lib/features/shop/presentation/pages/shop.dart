import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:maxless/core/component/custom-product-card.dart';
import 'package:maxless/core/constants/app_colors.dart';
import 'package:maxless/core/component/custom-header.dart';

class ShopPage extends StatefulWidget {
  @override
  _ShopPageState createState() => _ShopPageState();
}

class _ShopPageState extends State<ShopPage> {
  String selectedCategory = "All";

  final List<Map<String, dynamic>> allProducts = [
    {
      "category": "Protein",
      "title": "Hair Protein",
      "price": 3000,
      "subtitle": "Shine Repair",
      "image": "./lib/assets/testProduct.png"
    },
    {
      "category": "After Care",
      "title": "Ultra Pink",
      "price": 3000,
      "subtitle": "Repair & Protect",
      "image": "./lib/assets/testProduct.png"
    },
    {
      "category": "After Care",
      "title": "Green Apple",
      "price": 3000,
      "subtitle": "Repair & Protect",
      "image": "./lib/assets/testProduct.png"
    },
    {
      "category": "Protein",
      "title": "MAROCCACARE",
      "price": 3000,
      "subtitle": "Hair Plastic Surgery",
      "image": "./lib/assets/testProduct.png"
    },
    {
      "category": "After Care",
      "title": "Sunrise Orange",
      "price": 3000,
      "subtitle": "Repair & Protect",
      "image": "./lib/assets/testProduct.png"
    },
    {
      "category": "All",
      "title": "SPONGE FREE EFF...",
      "price": 3000,
      "subtitle": "Crystal Shine",
      "image": "./lib/assets/testProduct.png"
    },
  ];

  List<Map<String, dynamic>> get filteredProducts {
    if (selectedCategory == "All") {
      return allProducts;
    }
    return allProducts
        .where((product) => product["category"] == selectedCategory)
        .toList();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          // Header
          SizedBox(height: 20.h),

          CustomHeader(
            title: "Shop",
            onBackPress: () {
              Navigator.pop(context);
            },
          ),
          SizedBox(height: 10.h),

          // Categories
          Padding(
            padding: EdgeInsets.symmetric(horizontal: 16.w),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                _buildCategoryButton("All", "./lib/assets/testProducts.png"),
                _buildCategoryButton("Protein", "./lib/assets/test.png"),
                _buildCategoryButton(
                    "After Care", "./lib/assets/testProducts2.png"),
              ],
            ),
          ),
          SizedBox(height: 20.h),

          // Products Grid
          Expanded(
            child: Padding(
              padding: EdgeInsets.symmetric(horizontal: 16.w),
              child: GridView.builder(
                physics: BouncingScrollPhysics(), // يجعل التمرير أكثر سلاسة

                itemCount: filteredProducts.length,
                gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  mainAxisSpacing: 16.h,
                  crossAxisSpacing: 16.w,
                  childAspectRatio: 0.75,
                ),
                itemBuilder: (context, index) {
                  final product = filteredProducts[index];
                  return AnimatedContainer(
                    duration: Duration(milliseconds: 200),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(15.r),
                      image: DecorationImage(
                        image: AssetImage('./lib/assets/icons/shape.png'),
                        fit: BoxFit.contain,
                      ),
                    ),
                    child: ProductCard(
                      imageUrl: product["image"],
                      title: product["title"],
                      subtitle: product["subtitle"],
                      price: product["price"].toDouble(),
                      onAddToCart: () {
                        print("Added ${product['title']} to cart.");
                      },
                      onFavoriteToggle: () {
                        print("Toggled favorite for ${product['title']}.");
                      },
                    ),
                  );
                },
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCategoryButton(String category, String iconPath) {
    return GestureDetector(
      onTap: () {
        setState(() {
          selectedCategory = category;
        });
      },
      child: Column(
        children: [
          AnimatedContainer(
            width: 80,
            height: 80,
            duration: Duration(milliseconds: 200),
            decoration: BoxDecoration(
                border: Border.all(
                  color: AppColors.primaryColor,
                  width: 2,
                ),
                color: selectedCategory == category
                    ? AppColors.primaryColor
                    : Colors.white,
                borderRadius: BorderRadius.circular(
                  100,
                )),
            child: Padding(
              padding: EdgeInsets.symmetric(horizontal: 16.w),
              child: Image.asset(
                iconPath,
                height: 24.h,
                width: 24.w,
              ),
            ),
          ),
          SizedBox(height: 8.h),
          Text(
            category,
            style: TextStyle(
              fontSize: 14.sp,
              fontWeight: FontWeight.bold,
              color: selectedCategory == category
                  ? AppColors.primaryColor
                  : Colors.black54,
            ),
          ),
        ],
      ),
    );
  }
}
