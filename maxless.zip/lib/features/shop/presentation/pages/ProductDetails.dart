import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:maxless/core/component/custom-header.dart';
import 'package:maxless/core/component/quantity-counter.dart';
import 'package:maxless/core/constants/app_colors.dart';
import 'package:maxless/core/constants/navigation.dart';
import 'package:maxless/core/constants/widgets/custom_button.dart';
import 'package:maxless/features/cart/presentation/pages/cart.dart';
import 'package:maxless/features/shop/presentation/pages/shop.dart';

class ProductDetailsPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          SizedBox(height: 20.h),

          // Header Section
          CustomHeader(
            title: "Product Details",
            onBackPress: () {
              Navigator.pop(context);
            },
          ),
          SizedBox(height: 10.h),

          // Main Content
          Expanded(
            child: Stack(
              children: [
                // Background Image
                Positioned.fill(
                  bottom: -50.h,
                  child: SvgPicture.asset(
                    './lib/assets/icons/bg.svg', // الخلفية
                    fit: BoxFit.cover,
                  ),
                ),
                Padding(
                  padding: EdgeInsets.all(16.0.w),
                  child: ListView(
                    physics: BouncingScrollPhysics(), // يجعل التمرير أكثر سلاسة

                    children: [
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          // Product Details
                          Expanded(
                            flex: 2,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                GestureDetector(
                                  child: Icon(
                                    CupertinoIcons.heart,
                                    color: AppColors.primaryColor,
                                    size: 24.sp,
                                  ),
                                ),
                                SizedBox(height: 8.h),
                                Text(
                                  "Hair Care",
                                  style: TextStyle(
                                    color: AppColors.primaryColor,
                                    fontSize: 16.sp,
                                  ),
                                ),
                                SizedBox(height: 8.h),
                                Text(
                                  "SPONGE FREE EFFECT",
                                  style: TextStyle(
                                    fontSize: 22.sp,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                                SizedBox(height: 4.h),
                                Text(
                                  "Shine Repair Serum",
                                  style: TextStyle(
                                    fontSize: 16.sp,
                                    color: Colors.black,
                                  ),
                                ),
                                SizedBox(height: 20.h),

                                // Ingredients Section
                                Text(
                                  "Ingredients:",
                                  style: TextStyle(
                                    fontWeight: FontWeight.bold,
                                    fontSize: 16.sp,
                                  ),
                                ),
                                SizedBox(height: 8.h),
                                Text(
                                  "Iron Protein,\nHyaluronic Acid,\n+PRODEW500.",
                                  style: TextStyle(
                                    fontSize: 14.sp,
                                    color: Colors.black87,
                                  ),
                                ),
                                SizedBox(height: 20.h),

                                // How to Use Section
                                Text(
                                  "How to use:",
                                  style: TextStyle(
                                    fontWeight: FontWeight.bold,
                                    fontSize: 16.sp,
                                  ),
                                ),
                                SizedBox(height: 8.h),
                                Text(
                                  "Apply a small amount on wet hair, gently massage focusing on the ends, and comb. Rinse with water in case of contact with eyes.\n\nSpecially formulated to moisturize dry hair without weighing it down. This nourishing serum is ideal for moisturizing and protecting dry and damaged hair.",
                                  style: TextStyle(
                                    fontSize: 14.sp,
                                    color: Colors.black87,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          SizedBox(width: 15.w),

                          // Product Image
                          Expanded(
                            flex: 1,
                            child: Center(
                              child: Image.asset(
                                "./lib/assets/testProduct.png", // صورة المنتج
                                height: 220.h, // تكبير الصورة
                                fit: BoxFit.contain,
                              ),
                            ),
                          ),
                        ],
                      ),
                      SizedBox(height: 20.h),

                      // Price Section
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            "3000 EGP",
                            style: TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize: 20.sp,
                              color: AppColors.primaryColor, // اللون مثل الصورة
                            ),
                          ),
                        ],
                      ),
                      SizedBox(height: 15.h),

                      // Quantity and Add to Cart Section
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          // Quantity Control
                          QuantityCounter(
                            initialQuantity: 1, // Optional, defaults to 1
                            onQuantityChanged: (newQuantity) {
                              print("Quantity updated to $newQuantity");
                              // Handle quantity update logic here
                            },
                          ),

                          // Add to Cart Button
                          CustomElevatedButton(
                            width: 150.w,
                            text: "Add to Cart",
                            onPressed: () {
                              _showBottomModal(context);
                            },
                            color: AppColors.primaryColor,
                            borderRadius: 10.r,
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

void _showBottomModal(BuildContext context) {
  showModalBottomSheet(
    backgroundColor: AppColors.white,
    context: context,
    isScrollControlled: true,
    shape: RoundedRectangleBorder(
      borderRadius: BorderRadius.vertical(top: Radius.circular(15.r)),
    ),
    builder: (BuildContext context) {
      return Padding(
        padding: EdgeInsets.symmetric(horizontal: 20.w, vertical: 16.h),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            // Success Icon and Product Title
            Row(
              children: [
                Icon(CupertinoIcons.check_mark_circled_solid,
                    color: AppColors.green, size: 40.sp),
                SizedBox(width: 12.w),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "De-Piel Hair Serum",
                      style: TextStyle(
                        fontSize: 16.sp,
                        fontWeight: FontWeight.bold,
                        color: Colors.black,
                      ),
                    ),
                    Text(
                      "Added to Cart",
                      style: TextStyle(
                        fontSize: 14.sp,
                        color: AppColors.green,
                      ),
                    ),
                  ],
                ),
              ],
            ),
            SizedBox(height: 20.h),

            // Cart Total Section
            Container(
              padding: EdgeInsets.symmetric(horizontal: 15.w, vertical: 10.h),
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.all(
                    Radius.circular(10),
                  ),
                  color: Color(0xffF5F5F5)),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    "Cart Total",
                    style: TextStyle(
                      fontSize: 13.sp,
                      fontWeight: FontWeight.w400,
                      color: Colors.black,
                    ),
                  ),
                  Text(
                    "EGP 3000",
                    style: TextStyle(
                      fontSize: 13.sp,
                      fontWeight: FontWeight.w400,
                      color: Colors.black,
                    ),
                  ),
                ],
              ),
            ),
            SizedBox(height: 30.h),

            // Buttons in Column
            Column(
              children: [
                CustomElevatedButton(
                  text: "Continue Shopping",
                  color: AppColors.primaryColor,
                  textColor: Colors.white,
                  onPressed: () {
                    print("Continue Shopping...");
                    // Navigator.pop(context); // إغلاق المودال
                    Navigator.pushAndRemoveUntil(
                      context,
                      MaterialPageRoute(builder: (context) => ShopPage()),
                      (route) =>
                          route.isFirst, // يبقي فقط أول صفحة (عادةً صفحة Home)
                    );
                  },
                ),
                SizedBox(height: 15.h), // مسافة بين الأزرار

                CustomElevatedButton(
                  text: "View Cart",
                  color: Colors.white,
                  borderColor: AppColors.primaryColor,
                  textColor: AppColors.primaryColor,
                  onPressed: () {
                    navigateTo(context, CartPage());
                  },
                ),
              ],
            ),
          ],
        ),
      );
    },
  );
}
