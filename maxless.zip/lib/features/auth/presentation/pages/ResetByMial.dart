import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:maxless/core/constants/app_colors.dart';
import 'package:maxless/core/constants/navigation.dart';
import 'package:maxless/core/constants/widgets/custom_button.dart';
import 'package:maxless/core/constants/widgets/custom_text_form_field.dart';
import 'package:maxless/features/auth/presentation/pages/OtpMail.dart';

class ResetByMail extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Padding(
          padding: EdgeInsets.symmetric(horizontal: 20.w),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Title
              Text(
                'Forgot Password',
                style: TextStyle(
                  fontSize: 24.sp,
                  fontWeight: FontWeight.bold,
                  color: Colors.black,
                ),
              ),
              SizedBox(height: 10.h),

              // Description
              Text(
                "Don't worry! It happens sometimes. Please enter the email associated with your account.",
                style: TextStyle(
                  fontSize: 14.sp,
                  color: Colors.black,
                ),
              ),
              SizedBox(height: 30.h),

              // Email Input
              CustomTextFormField(
                labelText: 'Email',
                hintText: 'Enter your email',
                keyboardType: TextInputType.emailAddress,
                borderRadius: 12.r,
              ),
              SizedBox(height: 30.h),

              // Send Code Button
              CustomElevatedButton(
                text: 'Send Code',
                onPressed: () {
                  print('Send Code Button Pressed');
                  navigateTo(context, OtpVerificationResetpassword(email: ""));
                },
                color: AppColors.primaryColor,
                borderRadius: 10.r,
                icon: Icon(
                  CupertinoIcons.right_chevron,
                  color: Colors.white,
                  size: 15.sp,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
