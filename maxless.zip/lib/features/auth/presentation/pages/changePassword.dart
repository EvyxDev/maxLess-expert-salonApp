import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:maxless/core/constants/app_colors.dart';
import 'package:maxless/core/constants/widgets/custom_button.dart';
import 'package:maxless/core/constants/widgets/custom_text_form_field.dart';

class ChangePassword extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Padding(
          padding: EdgeInsets.symmetric(horizontal: 20.w),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Title
              Text(
                'Change Password',
                style: TextStyle(
                  fontSize: 24.sp,
                  fontWeight: FontWeight.bold,
                  color: Colors.black,
                ),
              ),
              SizedBox(height: 30.h),

              // New Password Field
              CustomTextFormField(
                labelText: 'New Password',
                hintText: 'Enter your password',
                obscureText: true,
                suffixIcon:
                    Icon(CupertinoIcons.eye_slash, color: AppColors.grey),
                borderRadius: 12.r,
              ),
              SizedBox(height: 20.h),

              // Confirm New Password Field
              CustomTextFormField(
                labelText: 'Confirm New Password',
                hintText: 'Enter your password',
                obscureText: true,
                suffixIcon:
                    Icon(CupertinoIcons.eye_slash, color: AppColors.grey),
                borderRadius: 12.r,
              ),
              SizedBox(height: 30.h),

              // Change Password Button
              CustomElevatedButton(
                text: 'Change',
                onPressed: () {
                  print('Change Password Button Pressed');
                },
                color: AppColors.primaryColor,
                borderRadius: 10.r,
                icon: Icon(
                  CupertinoIcons.right_chevron,
                  color: Colors.white,
                  size: 15.sp,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
