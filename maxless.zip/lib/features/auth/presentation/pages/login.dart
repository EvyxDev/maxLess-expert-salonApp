import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:maxless/core/constants/app_colors.dart';
import 'package:maxless/core/constants/navigation.dart';
import 'package:maxless/core/constants/widgets/custom_button.dart';
import 'package:maxless/core/constants/widgets/custom_text_form_field.dart';
import 'package:maxless/features/auth/presentation/pages/ForgotPassword.dart';
import 'package:maxless/features/auth/presentation/pages/sign-up.dart';

class Login extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            child: Padding(
              padding: EdgeInsets.symmetric(horizontal: 20.w),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  // Logo Section
                  Center(
                    child: Column(
                      children: [
                        SvgPicture.asset(
                          "./lib/assets/logo.svg",
                          height: 100.h, // حجم شعار ديناميكي
                        ),
                      ],
                    ),
                  ),
                  SizedBox(height: 50.h),

                  // Email or Phone Field
                  CustomTextFormField(
                    borderRadius: 12.r,
                    labelText: 'Email or Phone Number',
                    hintText: 'Enter your email or phone number',
                    keyboardType: TextInputType.emailAddress,
                  ),
                  SizedBox(height: 20.h),

                  // Password Field
                  CustomTextFormField(
                    borderRadius: 12.r,
                    labelText: 'Password',
                    hintText: 'Enter your password',
                    obscureText: true,
                    suffixIcon: Icon(
                      CupertinoIcons.eye_slash,
                      color: AppColors.grey,
                      size: 20.sp,
                    ),
                  ),
                  SizedBox(height: 20.h),

                  // Remember Me and Forgot Password Row
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Row(
                        children: [
                          Checkbox(
                            value: false,
                            onChanged: (value) {},
                            materialTapTargetSize: MaterialTapTargetSize
                                .shrinkWrap, // تقليل حجم الـCheckbox
                          ),
                          Text(
                            'Remember me',
                            style: TextStyle(
                              fontSize: 14.sp,
                              color: Colors.black,
                            ),
                          ),
                        ],
                      ),
                      TextButton(
                        onPressed: () {
                          navigateTo(context, ForgotPassword());
                        },
                        child: Text(
                          'Forgot Password',
                          style: TextStyle(
                            color: Colors.black,
                            fontSize: 14.sp,
                          ),
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: 30.h),

                  // Login Button
                  CustomElevatedButton(
                    text: 'Login',
                    onPressed: () {
                      print('Login button pressed');
                    },
                    color: AppColors.primaryColor,
                    borderRadius: 10.r,
                    icon: Icon(
                      CupertinoIcons.right_chevron,
                      color: Colors.white,
                      size: 15.sp,
                    ),
                  ),
                  SizedBox(height: 30.h),

                  // Sign Up Text
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        "Don't have an account? ",
                        style: TextStyle(
                          color: Colors.black,
                          fontSize: 14.sp,
                        ),
                      ),
                      TextButton(
                        onPressed: () {
                          navigateTo(context, SignUp());
                        },
                        child: Text(
                          'Sign up',
                          style: TextStyle(
                            color: AppColors.primaryColor,
                            fontWeight: FontWeight.bold,
                            fontSize: 14.sp,
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
