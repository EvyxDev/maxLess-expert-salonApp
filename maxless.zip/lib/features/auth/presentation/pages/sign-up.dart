import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:maxless/core/constants/app_colors.dart';
import 'package:maxless/core/constants/navigation.dart';
import 'package:maxless/core/constants/widgets/custom_button.dart';
import 'package:maxless/core/constants/widgets/custom_text_form_field.dart';
import 'package:maxless/features/auth/presentation/pages/login.dart';
import 'package:maxless/features/auth/presentation/pages/verifyAccount.dart';
import 'package:flutter_svg/flutter_svg.dart';

class SignUp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            child: Padding(
              padding: EdgeInsets.symmetric(horizontal: 20.w),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  // Logo Section
                  Center(
                    child: Column(
                      children: [
                        SvgPicture.asset(
                          "./lib/assets/logo.svg",
                          width: 150.w, // ضبط الريسبونسيف
                          height: 150.h,
                        ),
                      ],
                    ),
                  ),
                  SizedBox(height: 50.h),

                  // Username Field
                  CustomTextFormField(
                    borderRadius: 12.r,
                    labelText: 'Username',
                    hintText: 'Enter your username',
                    keyboardType: TextInputType.text,
                  ),
                  SizedBox(height: 20.h),

                  // Email Field
                  CustomTextFormField(
                    borderRadius: 12.r,
                    labelText: 'Email',
                    hintText: 'Enter your email',
                    keyboardType: TextInputType.emailAddress,
                  ),
                  SizedBox(height: 20.h),

                  // Phone Number Field
                  CustomTextFormField(
                    borderRadius: 12.r,
                    labelText: 'Phone Number',
                    hintText: 'Enter your phone number',
                    keyboardType: TextInputType.phone,
                  ),
                  SizedBox(height: 20.h),

                  // Password Field
                  CustomTextFormField(
                    borderRadius: 12.r,
                    labelText: 'Password',
                    hintText: 'Enter your password',
                    obscureText: true,
                    suffixIcon:
                        Icon(CupertinoIcons.eye_slash, color: AppColors.grey),
                  ),
                  SizedBox(height: 20.h),

                  // Confirm Password Field
                  CustomTextFormField(
                    borderRadius: 12.r,
                    labelText: 'Confirm Password',
                    hintText: 'Confirm your password',
                    obscureText: true,
                    suffixIcon:
                        Icon(CupertinoIcons.eye_slash, color: AppColors.grey),
                  ),
                  SizedBox(height: 30.h),

                  // Create Account Button
                  CustomElevatedButton(
                    text: 'Create account',
                    onPressed: () {
                      // تنفيذ الإجراء عند النقر
                      print('Create account button pressed');
                      navigateTo(context, VerifyAccount());
                    },
                    color: AppColors.primaryColor,
                    borderRadius: 10.r,
                    icon: Icon(
                      CupertinoIcons.right_chevron,
                      color: Colors.white,
                      size: 15.sp,
                    ),
                  ),
                  SizedBox(height: 30.h),

                  // Already have an account? Log In
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        "Already have an account? ",
                        style: TextStyle(
                          color: Colors.black,
                          fontSize: 14.sp,
                        ),
                      ),
                      TextButton(
                        onPressed: () {
                          // Navigate to Login Page
                          Navigator.pop(context);
                        },
                        child: Text(
                          'Log In',
                          style: TextStyle(
                            color: AppColors.primaryColor,
                            fontWeight: FontWeight.bold,
                            fontSize: 14.sp,
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
