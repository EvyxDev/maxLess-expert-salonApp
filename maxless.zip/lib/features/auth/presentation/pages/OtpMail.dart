import 'dart:async';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:maxless/core/constants/app_colors.dart';
import 'package:maxless/core/constants/navigation.dart';
import 'package:maxless/core/constants/widgets/custom_button.dart';
import 'package:maxless/features/auth/presentation/pages/changePassword.dart';

class OtpVerificationResetpassword extends StatefulWidget {
  final String email;

  OtpVerificationResetpassword({required this.email});

  @override
  _OtpVerificationResetpasswordState createState() =>
      _OtpVerificationResetpasswordState();
}

class _OtpVerificationResetpasswordState
    extends State<OtpVerificationResetpassword> {
  List<TextEditingController> otpControllers = [];
  int remainingTime = 20; // الوقت المتبقي لإعادة الإرسال
  Timer? timer;

  @override
  void initState() {
    super.initState();
    // إنشاء 4 حقول إدخال
    otpControllers = List.generate(4, (index) => TextEditingController());
    startTimer();
  }

  @override
  void dispose() {
    timer?.cancel();
    for (var controller in otpControllers) {
      controller.dispose();
    }
    super.dispose();
  }

  void startTimer() {
    timer = Timer.periodic(Duration(seconds: 1), (timer) {
      if (remainingTime > 0) {
        setState(() {
          remainingTime--;
        });
      } else {
        timer.cancel();
      }
    });
  }

  void resendCode() {
    setState(() {
      remainingTime = 20;
    });
    startTimer();
    print("Resending OTP...");
  }

  void verifyOtp() {
    String otp = otpControllers.map((e) => e.text).join();
    if (otp.length == 4) {
      print("Verifying OTP: $otp");
      // Add your verification logic here
    } else {
      print("Incomplete OTP");
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Padding(
          padding: EdgeInsets.symmetric(horizontal: 20.w),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Title
              Text(
                'Please check your email',
                style: TextStyle(
                  fontSize: 24.sp,
                  fontWeight: FontWeight.bold,
                  color: Colors.black,
                ),
              ),
              SizedBox(height: 10.h),

              // Description
              Text(
                "We’ve sent you a code to ${widget.email}",
                style: TextStyle(
                  fontSize: 14.sp,
                  color: Colors.black,
                ),
                textAlign: TextAlign.center,
              ),
              SizedBox(height: 30.h),

              // OTP Input Fields
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: List.generate(
                  4,
                  (index) => _buildOtpField(index),
                ),
              ),
              SizedBox(height: 30.h),

              // Verify Button
              CustomElevatedButton(
                text: 'Verify',
                onPressed: () {
                  navigateTo(context, ChangePassword());
                },
                color: AppColors.primaryColor,
                borderRadius: 10.r,
                icon: Icon(
                  CupertinoIcons.right_chevron,
                  color: Colors.white,
                  size: 15.sp,
                ),
              ),
              SizedBox(height: 20.h),

              // Resend Code Timer
              Center(
                child: GestureDetector(
                  onTap: remainingTime == 0 ? resendCode : null,
                  child: Text(
                    remainingTime == 0
                        ? 'Send code again'
                        : 'Send code again in 00:${remainingTime.toString().padLeft(2, '0')}',
                    style: TextStyle(
                      color: remainingTime == 0
                          ? AppColors.primaryColor
                          : Colors.black,
                      fontSize: 14.sp,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildOtpField(int index) {
    return SizedBox(
      width: 60.w,
      height: 60.h,
      child: TextField(
        controller: otpControllers[index],
        keyboardType: TextInputType.number,
        textAlign: TextAlign.center,
        maxLength: 1,
        style: TextStyle(
          fontSize: 24.sp,
          fontWeight: FontWeight.bold,
        ),
        decoration: InputDecoration(
          counterText: '',
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12.r),
            borderSide: BorderSide(
              color: Colors.black12,
            ),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12.r),
            borderSide: BorderSide(
              color: AppColors.primaryColor,
            ),
          ),
        ),
        onChanged: (value) {
          if (value.isNotEmpty && index < otpControllers.length - 1) {
            FocusScope.of(context).nextFocus();
          } else if (value.isEmpty && index > 0) {
            FocusScope.of(context).previousFocus();
          }
        },
      ),
    );
  }
}
