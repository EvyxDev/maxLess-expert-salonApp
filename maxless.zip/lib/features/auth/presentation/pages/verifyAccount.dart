import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:maxless/core/constants/app_colors.dart';
import 'package:maxless/core/constants/navigation.dart';
import 'package:maxless/features/auth/presentation/pages/ResetByMial.dart';
import 'package:maxless/features/auth/presentation/pages/verifyByMail.dart';

class VerifyAccount extends StatefulWidget {
  @override
  _VerifyAccountState createState() => _VerifyAccountState();
}

class _VerifyAccountState extends State<VerifyAccount> {
  // متغير لتحديد العنصر المختار
  String selectedOption = 'email'; // افتراضيًا Email هو المحدد

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Padding(
          padding: EdgeInsets.symmetric(horizontal: 20.w),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              SizedBox(height: 30.h),
              // Title
              Text(
                'Verify Your Account',
                style: TextStyle(
                  fontSize: 24.sp,
                  fontWeight: FontWeight.bold,
                  color: Colors.black,
                ),
              ),
              SizedBox(height: 10.h),
              // Description
              Text(
                'Select which contact details should we use to reset your password',
                style: TextStyle(
                  fontSize: 14.sp,
                  color: Colors.black,
                ),
              ),
              SizedBox(height: 30.h),
              // Options
              Row(
                children: [
                  // Email Option
                  Expanded(
                    child: GestureDetector(
                      onTap: () {
                        setState(() {
                          selectedOption = 'email'; // تحديث التحديد
                        });
                        navigateTo(context,
                            OtpVerification(email: "example@gmail.com"));
                      },
                      child: Container(
                        padding: EdgeInsets.all(16.w),
                        decoration: BoxDecoration(
                          color: Color(0xFFFAFAFA),
                          borderRadius: BorderRadius.circular(12.r),
                          border: Border.all(
                            color: selectedOption == 'email'
                                ? AppColors.primaryColor
                                : Colors.black12, // فريم إذا كان محددًا
                            width: 1.5.w,
                          ),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Container(
                              padding: EdgeInsets.all(10.w),
                              decoration: BoxDecoration(
                                color: AppColors.white,
                                borderRadius: BorderRadius.circular(100.r),
                                border: Border.all(
                                  color: selectedOption == 'email'
                                      ? AppColors.primaryColor
                                      : Colors.black12, // فريم إذا كان محددًا
                                  width: 1.5.w,
                                ),
                              ),
                              child: Icon(
                                CupertinoIcons.envelope,
                                color: AppColors.primaryColor,
                                size: 25.sp,
                              ),
                            ),
                            SizedBox(height: 13.h),
                            Text(
                              'Email',
                              style: TextStyle(
                                fontSize: 16.sp,
                                fontWeight: FontWeight.w400,
                                color: Colors.black,
                              ),
                            ),
                            SizedBox(height: 5.h),
                            Text(
                              'Send to your email',
                              style: TextStyle(
                                fontSize: 12.sp,
                                color: Colors.black,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                  SizedBox(width: 20.w),
                  // Phone Number Option
                  Expanded(
                    child: GestureDetector(
                      onTap: () {
                        setState(() {
                          selectedOption = 'phone'; // تحديث التحديد
                        });
                      },
                      child: Container(
                        padding: EdgeInsets.all(16.w),
                        decoration: BoxDecoration(
                          color: Color(0xFFFAFAFA),
                          borderRadius: BorderRadius.circular(12.r),
                          border: Border.all(
                            color: selectedOption == 'phone'
                                ? AppColors.primaryColor
                                : Colors.black12, // فريم إذا كان محددًا
                            width: 1.5.w,
                          ),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Container(
                              padding: EdgeInsets.all(10.w),
                              decoration: BoxDecoration(
                                color: AppColors.white,
                                borderRadius: BorderRadius.circular(100.r),
                                border: Border.all(
                                  color: selectedOption == 'phone'
                                      ? AppColors.primaryColor
                                      : Colors.black12, // فريم إذا كان محددًا
                                  width: 1.5.w,
                                ),
                              ),
                              child: Icon(
                                CupertinoIcons.phone,
                                color: AppColors.primaryColor,
                                size: 25.sp,
                              ),
                            ),
                            SizedBox(height: 13.h),
                            Text(
                              'Phone Number',
                              style: TextStyle(
                                fontSize: 16.sp,
                                fontWeight: FontWeight.w400,
                                color: Colors.black,
                              ),
                            ),
                            SizedBox(height: 5.h),
                            Text(
                              'Send to your phone',
                              style: TextStyle(
                                fontSize: 12.sp,
                                color: Colors.black,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
