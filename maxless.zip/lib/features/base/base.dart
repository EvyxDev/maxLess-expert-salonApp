import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:maxless/core/constants/app_colors.dart';
import 'package:maxless/features/cart/presentation/pages/cart.dart';
import 'package:maxless/features/home/presentation/pages/home.dart';
import 'package:maxless/features/profile/presentation/pages/main-profile.dart';
import 'package:maxless/features/shop/presentation/pages/shop.dart';
import 'package:maxless/features/wishlist/presentation/pages/wishlist.dart';

class BaseScreen extends StatefulWidget {
  @override
  _BaseScreenState createState() => _BaseScreenState();
}

class _BaseScreenState extends State<BaseScreen> {
  int _selectedIndex = 0;

  final List<Widget> _screens = [
    Center(child: HomePage()),
    Center(child: WishlistPage()),
    Center(child: ShopPage()),
    Center(child: CartPage()),
    Center(child: ProfilePage()),
  ];

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _screens[_selectedIndex],
      bottomNavigationBar: Stack(
        clipBehavior: Clip.none,
        children: [
          Positioned(
              bottom: 0,
              left: 0,
              right: 0,
              child: SvgPicture.asset(
                "lib/assets/icons/nav/Union.svg",
                height: 107.h,
              )),
          BottomAppBar(
            shape: CircularNotchedRectangle(),
            color: Colors.transparent,
            notchMargin: 8.0,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: <Widget>[
                // Home Button
                _buildNavBarItem(
                  icon: "lib/assets/icons/nav/home.svg",
                  index: 0,
                  label: "Home",
                ),
                // Wishlist Button
                _buildNavBarItem(
                  icon: "lib/assets/icons/nav/love.svg",
                  index: 1,
                  label: "Wishlist",
                ),
                SizedBox(width: 50), // Space for Floating Action Button
                // Cart Button
                _buildNavBarItem(
                  icon: "lib/assets/icons/nav/cart.svg",
                  index: 3,
                  label: "Cart",
                ),
                // Profile Button
                _buildNavBarItem(
                  icon: "lib/assets/icons/nav/user.svg",
                  index: 4,
                  label: "Profile",
                ),
              ],
            ),
          ),
          // Floating Action Button
          Positioned(
            bottom: 43.h,
            left: 0,
            right: 0,
            child: GestureDetector(
              onTap: () {
                _onItemTapped(2);
              },
              child: Container(
                width: 50,
                height: 50,
                decoration: BoxDecoration(
                  color: AppColors.primaryColor,
                  shape: BoxShape.circle,
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.2),
                      spreadRadius: 2,
                      blurRadius: 10,
                      offset: Offset(0, 5), // تحريك الظل لأسفل
                    ),
                  ],
                ),
                child: Center(
                  child: SvgPicture.asset("lib/assets/icons/nav/shop.svg"),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildNavBarItem(
      {required String icon, required int index, required String label}) {
    final bool isSelected = _selectedIndex == index;
    return GestureDetector(
      onTap: () => _onItemTapped(index),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          SvgPicture.asset(
            icon,
            color: isSelected ? AppColors.primaryColor : Colors.grey,
          ),
          if (isSelected)
            Text(
              label,
              style: TextStyle(
                color: AppColors.primaryColor,
                fontSize: 12,
              ),
            ),
        ],
      ),
    );
  }
}
